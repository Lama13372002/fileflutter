package com.example.flutter_ai_assistant

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
