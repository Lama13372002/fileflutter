import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:provider/provider.dart';
import '../services/api_service.dart';

class TypingIndicator extends StatelessWidget {
  const TypingIndicator({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final apiService = Provider.of<ApiService>(context, listen: false);

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          '${apiService.currentModel.name} думает',
          style: TextStyle(
            color: theme.colorScheme.onSecondaryContainer,
            fontStyle: FontStyle.italic,
          ),
        ),
        const SizedBox(width: 8),
        SpinKitThreeBounce(
          color: theme.colorScheme.onSecondaryContainer,
          size: 16,
        ),
      ],
    ).animate(
      onPlay: (controller) => controller.repeat(),
    ).fade(
      duration: 600.ms,
      curve: Curves.easeInOut,
      begin: 0.7,
      end: 1.0,
    );
  }
}
