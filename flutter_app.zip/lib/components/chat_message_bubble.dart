import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:provider/provider.dart';
import '../models/message.dart';
import '../services/api_service.dart';
import 'typing_indicator.dart';

class ChatMessageBubble extends StatelessWidget {
  final Message message;
  final bool shouldAnimate;
  final VoidCallback? onLongPress;

  const ChatMessageBubble({
    Key? key,
    required this.message,
    this.shouldAnimate = false,
    this.onLongPress,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final isUser = message.role == MessageRole.user;
    final isSystem = message.role == MessageRole.system;
    final theme = Theme.of(context);
    final apiService = Provider.of<ApiService>(context, listen: false);

    // Отображаем системные сообщения по-особому
    if (isSystem) {
      return _buildSystemMessage(theme);
    }

    return Column(
      children: [
        // Временная метка над сообщением
        Padding(
          padding: const EdgeInsets.only(top: 8.0, bottom: 4.0),
          child: Text(
            _formatTime(message.timestamp),
            style: TextStyle(
              fontSize: 11,
              color: theme.colorScheme.onSurface.withOpacity(0.5),
            ),
          ),
        ),

        // Сообщение
        Align(
          alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
          child: GestureDetector(
            onLongPress: onLongPress,
            child: ConstrainedBox(
              constraints: BoxConstraints(
                maxWidth: isUser
                    ? MediaQuery.of(context).size.width * 0.85
                    : MediaQuery.of(context).size.width * 0.90, // Увеличиваем ширину для сообщений ИИ
              ),
              child: Card(
                color: isUser
                    ? theme.colorScheme.primary
                    : theme.colorScheme.secondaryContainer,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20), // Используем одинаковое скругление для всех углов
                ),
                elevation: 1,
                margin: EdgeInsets.only(
                  left: isUser ? 64 : 12, // Уменьшаем левый отступ для сообщений ИИ
                  right: isUser ? 16 : 48, // Уменьшаем правый отступ для сообщений ИИ
                  bottom: 8,
                ),
                child: Stack(
                  children: [
                    // Основное содержимое сообщения
                    Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: _buildMessageContent(context),
                    ),

                    // Индикатор источника (для сообщений ассистента)
                    if (!isUser && !message.isLoading)
                      Positioned(
                        top: 4,
                        right: 8,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              apiService.currentModel.icon,
                              size: 12,
                              color: apiService.currentModel.color.withOpacity(Theme.of(context).brightness == Brightness.dark ? 0.9 : 0.7),
                            ),
                            const SizedBox(width: 4),
                            Text(
                              apiService.currentModel.name,
                              style: TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                                color: theme.colorScheme.onSecondaryContainer.withOpacity(0.7),
                              ),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  // Отображение системного сообщения
  Widget _buildSystemMessage(ThemeData theme) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
      child: Center(
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 6.0, horizontal: 16.0),
          decoration: BoxDecoration(
            color: theme.colorScheme.surface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: theme.colorScheme.outline.withOpacity(0.3),
              width: 1,
            ),
          ),
          child: Text(
            message.content,
            style: TextStyle(
              fontSize: 13,
              color: theme.colorScheme.onSurface.withOpacity(0.8),
            ),
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }

  Widget _buildMessageContent(BuildContext context) {
    final isUser = message.role == MessageRole.user;
    final theme = Theme.of(context);
    final textColor = isUser
        ? theme.colorScheme.onPrimary
        : theme.colorScheme.onSecondaryContainer;

    // Если сообщение загружается, показываем индикатор набора текста
    if (message.isLoading && message.content.isEmpty) {
      return const TypingIndicator();
    }

    // Если сообщение загружается, но уже есть текст, показываем текст с индикатором
    if (message.isLoading && message.content.isNotEmpty) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Основной текст сообщения с поддержкой форматирования
          _getTextWidget(message.content, textColor, context),

          // Индикатор, что еще идет загрузка
          const SizedBox(height: 8),
          const SpinKitThreeBounce(
            color: Colors.grey,
            size: 12,
          ),
        ],
      );
    }

    Widget content;

    switch (message.type) {
      case MessageType.image:
        content = Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (message.file != null)
              GestureDetector(
                onTap: () {
                  // Показываем изображение в полноэкранном режиме при нажатии
                  _showFullScreenImage(context, message.file!);
                },
                child: Hero(
                  tag: 'image_${message.id}',
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: Image.file(
                      message.file!,
                      fit: BoxFit.contain,
                      width: MediaQuery.of(context).size.width * 0.7,
                    ),
                  ),
                ),
              )
            else if (message.fileData != null)
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.memory(
                  message.fileData!,
                  fit: BoxFit.cover,
                  width: MediaQuery.of(context).size.width * 0.7,
                ),
              ),
            if (message.content.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: _getTextWidget(message.content, textColor, context),
              ),
          ],
        );
        break;

      case MessageType.file:
        content = Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: isUser
                    ? theme.colorScheme.primaryContainer.withOpacity(0.3)
                    : theme.colorScheme.secondaryContainer.withOpacity(0.3),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: theme.colorScheme.outline.withOpacity(0.2),
                  width: 1,
                ),
              ),
              child: InkWell(
                onTap: () {
                  // В будущем можно добавить открытие файла
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Открытие файла ${message.fileName ?? ""}'),
                      duration: const Duration(seconds: 1),
                    ),
                  );
                },
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Иконка в зависимости от типа файла
                    _getFileIcon(message.fileName, theme),
                    const SizedBox(width: 12),
                    Flexible(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            message.fileName ?? 'Документ',
                            style: TextStyle(
                              color: textColor,
                              fontWeight: FontWeight.bold,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Нажмите, чтобы открыть',
                            style: TextStyle(
                              color: textColor.withOpacity(0.7),
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            if (message.content.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: _getTextWidget(message.content, textColor, context),
              ),
          ],
        );
        break;

      case MessageType.audio:
        content = Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: isUser
                    ? theme.colorScheme.primaryContainer.withOpacity(0.3)
                    : theme.colorScheme.secondaryContainer.withOpacity(0.3),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: theme.colorScheme.outline.withOpacity(0.2),
                  width: 1,
                ),
              ),
              child: InkWell(
                onTap: () {
                  // В будущем можно добавить воспроизведение аудио
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Воспроизведение аудио ${message.fileName ?? ""}'),
                      duration: const Duration(seconds: 1),
                    ),
                  );
                },
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: Colors.purple.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Center(
                        child: Icon(
                          Icons.audiotrack,
                          color: Colors.purple,
                          size: 24,
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Flexible(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            message.fileName ?? 'Аудиозапись',
                            style: TextStyle(
                              color: textColor,
                              fontWeight: FontWeight.bold,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 4),
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.play_arrow,
                                size: 16,
                                color: textColor.withOpacity(0.7),
                              ),
                              const SizedBox(width: 4),
                              Text(
                                'Нажмите для воспроизведения',
                                style: TextStyle(
                                  color: textColor.withOpacity(0.7),
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            if (message.content.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: _getTextWidget(message.content, textColor, context),
              ),
          ],
        );
        break;

      case MessageType.video:
        content = Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: isUser
                    ? theme.colorScheme.primaryContainer.withOpacity(0.3)
                    : theme.colorScheme.secondaryContainer.withOpacity(0.3),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Stack(
                    alignment: Alignment.center,
                    children: [
                      Container(
                        width: 60,
                        height: 60,
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: message.file != null
                            ? ClipRRect(
                                borderRadius: BorderRadius.circular(8),
                                child: Container(
                                  color: Colors.black38,
                                ),
                              )
                            : null,
                      ),
                      Icon(
                        Icons.play_circle_fill,
                        color: Colors.white.withOpacity(0.8),
                        size: 30,
                      ),
                    ],
                  ),
                  const SizedBox(width: 12),
                  Flexible(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          message.fileName ?? 'Видео',
                          style: TextStyle(
                            color: textColor,
                            fontWeight: FontWeight.bold,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Нажмите, чтобы открыть',
                          style: TextStyle(
                            color: textColor.withOpacity(0.7),
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            if (message.content.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: _getTextWidget(message.content, textColor, context),
              ),
          ],
        );
        break;

      case MessageType.text:
      default:
        content = _getTextWidget(message.content, textColor, context);
        break;
    }

    // Применяем анимацию только к сообщениям ассистента
    if (shouldAnimate && !isUser) {
      return content.animate()
        .fadeIn(duration: 300.ms)
        .scale(
          begin: const Offset(0.95, 0.95),
          end: const Offset(1.0, 1.0),
          duration: 350.ms,
        );
    }

    return content;
  }

  // Вспомогательный метод для создания виджета текста с поддержкой форматирования
  Widget _getTextWidget(String text, Color textColor, BuildContext context) {
    // Проверяем, содержит ли текст форматирование Markdown
    final hasMarkdown = text.contains('**') ||
                       text.contains('*') ||
                       text.contains('__') ||
                       text.contains('_') ||
                       text.contains('```') ||
                       text.contains('`') ||
                       text.contains('#') ||
                       text.contains('- ') ||
                       text.contains('1. ') ||
                       text.contains('[') && text.contains('](');

    if (hasMarkdown) {
      // Используем Markdown для форматированного текста
      return MarkdownBody(
        data: text,
        styleSheet: MarkdownStyleSheet(
          p: TextStyle(color: textColor),
          strong: TextStyle(color: textColor, fontWeight: FontWeight.bold),
          em: TextStyle(color: textColor, fontStyle: FontStyle.italic), // Изменено с emphasis на em
          code: TextStyle(
            color: textColor,
            backgroundColor: Colors.black12,
            fontFamily: 'monospace',
          ),
          codeblockDecoration: BoxDecoration(
            color: Colors.black12,
            borderRadius: BorderRadius.circular(4),
          ),
        ),
      );
    } else {
      // Для обычного текста используем стандартный Text виджет
      return Text(
        text,
        style: TextStyle(color: textColor),
      );
    }
  }

  // Форматирование времени
  String _formatTime(DateTime dateTime) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final yesterday = today.subtract(const Duration(days: 1));
    final messageDate = DateTime(dateTime.year, dateTime.month, dateTime.day);

    String prefix = '';

    if (messageDate == today) {
      prefix = 'Сегодня, ';
    } else if (messageDate == yesterday) {
      prefix = 'Вчера, ';
    } else {
      prefix = '${dateTime.day}.${dateTime.month}.${dateTime.year}, ';
    }

    return '$prefix${dateTime.hour.toString().padLeft(2, '0')}:${dateTime.minute.toString().padLeft(2, '0')}';
  }

  // Получает иконку файла в зависимости от его типа
  Widget _getFileIcon(String? fileName, ThemeData theme) {
    if (fileName == null) return Icon(Icons.insert_drive_file, color: theme.colorScheme.primary);

    final extension = fileName.toLowerCase().split('.').last;

    // Цвета и иконки для разных типов файлов
    IconData iconData;
    Color iconColor;

    switch (extension) {
      case 'pdf':
        iconData = Icons.picture_as_pdf;
        iconColor = Colors.red;
        break;
      case 'doc':
      case 'docx':
        iconData = Icons.description;
        iconColor = Colors.blue;
        break;
      case 'xls':
      case 'xlsx':
        iconData = Icons.table_chart;
        iconColor = Colors.green;
        break;
      case 'ppt':
      case 'pptx':
        iconData = Icons.slideshow;
        iconColor = Colors.orange;
        break;
      case 'txt':
        iconData = Icons.article;
        iconColor = Colors.teal;
        break;
      case 'zip':
      case 'rar':
        iconData = Icons.folder_zip;
        iconColor = Colors.amber;
        break;
      default:
        iconData = Icons.insert_drive_file;
        iconColor = theme.colorScheme.primary;
    }

    return Container(
      width: 44,
      height: 44,
      decoration: BoxDecoration(
        color: iconColor.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Center(
        child: Icon(
          iconData,
          color: iconColor,
          size: 24,
        ),
      ),
    );
  }

  // Метод для отображения изображения в полноэкранном режиме
  void _showFullScreenImage(BuildContext context, File image) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => Scaffold(
          backgroundColor: Colors.black,
          appBar: AppBar(
            backgroundColor: Colors.black,
            iconTheme: const IconThemeData(color: Colors.white),
          ),
          body: Center(
            child: Hero(
              tag: 'image_${message.id}',
              child: InteractiveViewer(
                minScale: 0.5,
                maxScale: 4.0,
                child: Image.file(
                  image,
                  fit: BoxFit.contain,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
