import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import '../models/message.dart';
import 'typing_indicator.dart';

class ChatMessageBubble extends StatelessWidget {
  final Message message;
  final bool shouldAnimate;

  const ChatMessageBubble({
    Key? key,
    required this.message,
    this.shouldAnimate = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final isUser = message.role == MessageRole.user;
    final theme = Theme.of(context);

    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: ConstrainedBox(
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width * 0.75,
        ),
        child: Card(
          color: isUser
              ? theme.colorScheme.primary.withOpacity(0.9)
              : theme.colorScheme.secondaryContainer,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          elevation: 1,
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: _buildMessageContent(context),
          ),
        ),
      ),
    );
  }

  Widget _buildMessageContent(BuildContext context) {
    final isUser = message.role == MessageRole.user;
    final theme = Theme.of(context);
    final textColor = isUser
        ? theme.colorScheme.onPrimary
        : theme.colorScheme.onSecondaryContainer;

    if (message.isLoading) {
      return const TypingIndicator();
    }

    Widget content;

    switch (message.type) {
      case MessageType.image:
        content = Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (message.file != null)
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.file(
                  message.file!,
                  fit: BoxFit.cover,
                ),
              )
            else if (message.fileData != null)
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.memory(
                  message.fileData!,
                  fit: BoxFit.cover,
                ),
              ),
            if (message.content.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: Text(
                  message.content,
                  style: TextStyle(color: textColor),
                ),
              ),
          ],
        );
        break;

      case MessageType.file:
        content = Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.insert_drive_file, color: textColor),
            const SizedBox(width: 8),
            Flexible(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    message.fileName ?? 'File',
                    style: TextStyle(
                      color: textColor,
                      fontWeight: FontWeight.bold,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  if (message.content.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 4.0),
                      child: Text(
                        message.content,
                        style: TextStyle(color: textColor),
                      ),
                    ),
                ],
              ),
            ),
          ],
        );
        break;

      case MessageType.audio:
        content = Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.audiotrack, color: textColor),
            const SizedBox(width: 8),
            Flexible(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    message.fileName ?? 'Audio',
                    style: TextStyle(
                      color: textColor,
                      fontWeight: FontWeight.bold,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  if (message.content.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 4.0),
                      child: Text(
                        message.content,
                        style: TextStyle(color: textColor),
                      ),
                    ),
                ],
              ),
            ),
          ],
        );
        break;

      case MessageType.video:
        content = Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.videocam, color: textColor),
            const SizedBox(width: 8),
            Flexible(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    message.fileName ?? 'Video',
                    style: TextStyle(
                      color: textColor,
                      fontWeight: FontWeight.bold,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  if (message.content.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 4.0),
                      child: Text(
                        message.content,
                        style: TextStyle(color: textColor),
                      ),
                    ),
                ],
              ),
            ),
          ],
        );
        break;

      case MessageType.text:
      default:
        content = Text(
          message.content,
          style: TextStyle(color: textColor),
        );
        break;
    }

    if (shouldAnimate && !isUser) {
      return content.animate()
        .fadeIn(duration: 300.ms)
        .scale(
          begin: const Offset(0.9, 0.9),
          end: const Offset(1.0, 1.0),
          duration: 350.ms,
        );
    }

    return content;
  }
}
