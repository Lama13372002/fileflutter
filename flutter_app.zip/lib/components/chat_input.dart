import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as path;
import 'package:mime/mime.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:permission_handler/permission_handler.dart';

class ChatInput extends StatefulWidget {
  final Function(String message, {File? file}) onSendMessage;
  final bool isLoading;

  const ChatInput({
    Key? key,
    required this.onSendMessage,
    this.isLoading = false,
  }) : super(key: key);

  @override
  State<ChatInput> createState() => _ChatInputState();
}

class _ChatInputState extends State<ChatInput> {
  final TextEditingController _controller = TextEditingController();
  final FocusNode _focusNode = FocusNode();

  File? _selectedFile;
  String? _fileName;

  bool _showAttachMenu = false;

  bool get _isComposing => _controller.text.isNotEmpty || _selectedFile != null;

  @override
  void initState() {
    super.initState();
    // Добавляем простой слушатель для обновления UI при изменении текста
    _controller.addListener(() {
      setState(() {});
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  // Метод для переключения меню вложений
  void _toggleAttachMenu() {
    print("Toggling attachment menu");
    setState(() {
      _showAttachMenu = !_showAttachMenu;
    });
  }

  Future<void> _pickImage(ImageSource source) async {
    print("Picking image from ${source == ImageSource.camera ? 'camera' : 'gallery'}");

    try {
      final hasPermission = await _requestPermission(
        source == ImageSource.camera
            ? Permission.camera
            : _getStoragePermission() // Используем метод для определения правильного разрешения
      );

      if (!hasPermission) {
        print("Permission denied");
        return;
      }

      final picker = ImagePicker();
      print("ImagePicker initialized");

      final pickedFile = await picker.pickImage(
        source: source,
        imageQuality: 70,
      );

      print("Image picked: ${pickedFile?.path}");

      if (pickedFile != null) {
        setState(() {
          _selectedFile = File(pickedFile.path);
          _fileName = path.basename(pickedFile.path);
          _showAttachMenu = false; // Скрываем меню после выбора
        });

        // Даем обратную связь пользователю
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("Изображение прикреплено"),
            duration: Duration(seconds: 1),
          ),
        );
      }
    } catch (e) {
      print("Error picking image: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Ошибка при выборе изображения: $e"),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  // Метод для определения нужного разрешения в зависимости от версии Android
  Permission _getStoragePermission() {
    // Android SDK выше или равно 33 (Android 13+)
    if (Platform.isAndroid) {
      try {
        // Получаем версию SDK Android
        final version = _getAndroidSdkInt();
        if (version >= 33) {
          return Permission.photos; // Для Android 13+ используем Permission.photos (или Permission.mediaImages если доступен)
        } else {
          return Permission.storage; // Для более старых версий используем Permission.storage
        }
      } catch (e) {
        // Если не удалось определить версию, по умолчанию storage
        return Permission.storage;
      }
    } else if (Platform.isIOS) {
      return Permission.photos;
    } else {
      return Permission.storage;
    }
  }

  int _getAndroidSdkInt() {
    // Platform.operatingSystemVersion может быть разным на разных устройствах,
    // поэтому лучше использовать Platform.version, но если недоступно —
    // делаем простейший парсер.
    // Обычно строка выглядит так: "Android 13 (SDK 33)"
    final osVersion = Platform.operatingSystemVersion;
    final sdkMatch = RegExp(r'SDK (\d+)').firstMatch(osVersion);
    if (sdkMatch != null) {
      return int.parse(sdkMatch.group(1)!);
    }
    // Альтернативный способ: если не нашли, пробуем по последнему числу
    final parts = osVersion.split(' ');
    for (var i = parts.length - 1; i >= 0; i--) {
      final n = int.tryParse(parts[i]);
      if (n != null) return n;
    }
    // Если не удалось определить, возвращаем 0
    return 0;
  }

  Future<void> _pickFile() async {
    print("Picking document file");

    try {
      final hasPermission = await _requestPermission(Permission.storage);

      if (!hasPermission) {
        print("Storage permission denied");
        return;
      }

      print("Opening file picker");
      final result = await FilePicker.platform.pickFiles(
        type: FileType.any,
        allowMultiple: false,
      );

      print("File picked: ${result?.files.single.name}");

      if (result != null && result.files.single.path != null) {
        setState(() {
          _selectedFile = File(result.files.single.path!);
          _fileName = result.files.single.name;
          _showAttachMenu = false; // Скрываем меню после выбора
        });

        // Даем обратную связь пользователю
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("Файл прикреплен: ${result.files.single.name}"),
            duration: Duration(seconds: 1),
          ),
        );
      }
    } catch (e) {
      print("Error picking file: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Ошибка при выборе файла: $e"),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Future<bool> _requestPermission(Permission permission) async {
    print("Requesting permission: $permission");

    try {
      final status = await permission.status;
      print("Permission status: $status");

      if (status.isGranted) {
        print("Permission already granted");
        return true;
      }

      if (status.isDenied) {
        print("Permission denied, requesting...");
        final result = await permission.request();
        print("Permission request result: $result");
        return result.isGranted;
      }

      if (status.isPermanentlyDenied) {
        print("Permission permanently denied");
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Приложению требуется доступ к ${_getPermissionName(permission)}. '
              'Пожалуйста, разрешите доступ в настройках.'
            ),
            action: SnackBarAction(
              label: 'Настройки',
              onPressed: () => openAppSettings(),
            ),
            duration: Duration(seconds: 5),
          ),
        );
        return false;
      }

      return false;
    } catch (e) {
      print("Error requesting permission: $e");
      return false;
    }
  }

  // Вспомогательный метод для получения понятного названия разрешения
  String _getPermissionName(Permission permission) {
    switch (permission) {
      case Permission.camera:
        return 'камере';
      case Permission.photos:
        return 'галерее';
      case Permission.storage:
        return 'хранилищу';
      default:
        return 'ресурсу';
    }
  }

  void _clearSelectedFile() {
    setState(() {
      _selectedFile = null;
      _fileName = null;
    });
  }

  void _handleSubmitted() {
    print("Handling message submission");
    final text = _controller.text.trim();

    if (text.isNotEmpty || _selectedFile != null) {
      print("Sending message: '$text' with file: ${_selectedFile?.path}");

      try {
        widget.onSendMessage(text, file: _selectedFile);
        _controller.clear();
        _clearSelectedFile();
      } catch (e) {
        print("Error sending message: $e");
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("Ошибка при отправке сообщения"),
            backgroundColor: Colors.red,
          ),
        );
      }
    } else {
      print("Nothing to send");
    }
  }

  String _getFileTypeIcon() {
    if (_selectedFile == null) return '';

    final fileExtension = path.extension(_selectedFile!.path).toLowerCase();
    final mimeType = lookupMimeType(_selectedFile!.path);

    if (mimeType?.startsWith('image/') ?? false) {
      return '🖼️';
    } else if (mimeType?.startsWith('video/') ?? false) {
      return '🎬';
    } else if (mimeType?.startsWith('audio/') ?? false) {
      return '🎵';
    } else if (fileExtension == '.pdf') {
      return '📄';
    } else if (fileExtension == '.doc' || fileExtension == '.docx') {
      return '📝';
    } else if (fileExtension == '.xls' || fileExtension == '.xlsx') {
      return '📊';
    } else if (fileExtension == '.ppt' || fileExtension == '.pptx') {
      return '📊';
    } else if (fileExtension == '.zip' || fileExtension == '.rar') {
      return '📦';
    }

    return '📎';
  }

  // Проверяет, является ли файл изображением
  bool _isSelectedFileImage() {
    if (_selectedFile == null) return false;
    final mimeType = lookupMimeType(_selectedFile!.path);
    return mimeType?.startsWith('image/') ?? false;
  }

  // Получает информацию о файле (размер, тип)
  String _getFileInfo() {
    if (_selectedFile == null) return '';

    try {
      final fileSize = _selectedFile!.lengthSync();
      String sizeStr;

      if (fileSize < 1024) {
        sizeStr = '$fileSize B';
      } else if (fileSize < 1024 * 1024) {
        sizeStr = '${(fileSize / 1024).toStringAsFixed(1)} KB';
      } else {
        sizeStr = '${(fileSize / (1024 * 1024)).toStringAsFixed(1)} MB';
      }

      final fileExtension = path.extension(_selectedFile!.path).toLowerCase();
      return '${fileExtension.toUpperCase().replaceAll('.', '')} · $sizeStr';
    } catch (e) {
      return 'Файл';
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Панель выбора вложений
        AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          height: _showAttachMenu ? 80 : 0,
          curve: Curves.easeInOut,
          color: theme.colorScheme.surface,
          child: SingleChildScrollView(
            physics: const NeverScrollableScrollPhysics(),
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _buildAttachOption(
                    icon: Icons.image,
                    label: 'Галерея',
                    color: Colors.blue,
                    onTap: () => _pickImage(ImageSource.gallery),
                  ),
                  _buildAttachOption(
                    icon: Icons.camera_alt,
                    label: 'Камера',
                    color: Colors.green,
                    onTap: () => _pickImage(ImageSource.camera),
                  ),
                  _buildAttachOption(
                    icon: Icons.insert_drive_file,
                    label: 'Документ',
                    color: Colors.orange,
                    onTap: _pickFile,
                  ),
                  _buildAttachOption(
                    icon: Icons.close,
                    label: 'Закрыть',
                    color: Colors.red,
                    onTap: _toggleAttachMenu,
                  ),
                ],
              ),
            ),
          ),
        ),

        // Выбранный файл
        if (_selectedFile != null)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
            margin: const EdgeInsets.only(bottom: 8.0, left: 12.0, right: 12.0),
            decoration: BoxDecoration(
              color: theme.colorScheme.secondaryContainer.withOpacity(0.5),
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: theme.shadowColor.withOpacity(0.1),
                  blurRadius: 4,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Row(
              children: [
                // Предпросмотр для изображений
                _isSelectedFileImage()
                    ? ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: Image.file(
                          _selectedFile!,
                          width: 40,
                          height: 40,
                          fit: BoxFit.cover,
                        ),
                      )
                    : Text(_getFileTypeIcon(), style: const TextStyle(fontSize: 20)),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        _fileName ?? 'Файл',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: theme.colorScheme.onSecondaryContainer,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      if (_selectedFile != null)
                        Text(
                          _getFileInfo(),
                          style: TextStyle(
                            fontSize: 12,
                            color: theme.colorScheme.onSecondaryContainer.withOpacity(0.7),
                          ),
                        ),
                    ],
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.close, size: 18),
                  onPressed: _clearSelectedFile,
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                  color: theme.colorScheme.onSecondaryContainer,
                ),
              ],
            ),
          ).animate().slideY(
            begin: 1,
            end: 0,
            curve: Curves.easeOutQuad,
            duration: 250.ms,
          ),

        // Поле ввода
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 12.0),
          decoration: BoxDecoration(
            color: theme.colorScheme.surface,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: 4,
                offset: const Offset(0, -1),
              ),
            ],
          ),
          child: SafeArea(
            child: Row(
              children: [
                // Кнопка прикрепления файлов
                IconButton(
                  icon: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: _showAttachMenu
                          ? theme.colorScheme.primary.withOpacity(0.2)
                          : Colors.transparent,
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      Icons.add,
                      color: _showAttachMenu
                          ? theme.colorScheme.primary
                          : theme.colorScheme.onSurface.withOpacity(0.7),
                    ),
                  ),
                  onPressed: widget.isLoading ? null : _toggleAttachMenu,
                  tooltip: 'Прикрепить файл',
                ),

                // Поле ввода текста
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      color: theme.colorScheme.surfaceVariant.withOpacity(0.7),
                      borderRadius: const BorderRadius.all(Radius.circular(24)),
                      border: Border.all(
                        color: theme.colorScheme.outline.withOpacity(0.1),
                        width: 1,
                      ),
                    ),
                    child: Row(
                      children: [
                        // Небольшой отступ с левой стороны для лучшего внешнего вида
                        const SizedBox(width: 12),

                        Expanded(
                          child: ConstrainedBox(
                            constraints: const BoxConstraints(
                              minHeight: 40.0, // Минимальная высота поля
                              maxHeight: 100.0, // Ограничиваем максимальную высоту
                            ),
                            child: TextField(
                              // TextField может сам управлять скроллингом с maxLines > 1
                              controller: _controller,
                              focusNode: _focusNode,
                              decoration: InputDecoration(
                                hintText: 'Напишите сообщение...',
                                border: InputBorder.none,
                                isDense: true,
                                contentPadding: const EdgeInsets.symmetric(vertical: 12),
                                hintStyle: TextStyle(
                                  color: theme.colorScheme.onSurface.withOpacity(0.5),
                                ),
                              ),
                              textCapitalization: TextCapitalization.sentences,
                              enabled: !widget.isLoading,
                              maxLines: 6, // Ограничиваем количество строк, чтобы не заполнять весь экран
                              minLines: 1,
                              // Используем multiline для возможности скроллинга и более удобного ввода
                              keyboardType: TextInputType.multiline,
                              textInputAction: TextInputAction.newline,
                              style: TextStyle(
                                fontSize: 16.0, // Оптимальный размер для чтения
                              ),
                              onChanged: (text) {
                                setState(() {});
                              },
                              scrollPhysics: const ClampingScrollPhysics(), // Для предсказуемого поведения
                            ),
                          ),
                        ),

                        // Кнопка отправки
                        Padding(
                          padding: const EdgeInsets.only(right: 4.0),
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 200),
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              color: _isComposing
                                  ? theme.colorScheme.primary
                                  : theme.colorScheme.surfaceVariant,
                              shape: BoxShape.circle,
                            ),
                            child: IconButton(
                              icon: Icon(
                                Icons.send,
                                size: 20,
                                color: _isComposing
                                    ? theme.colorScheme.onPrimary
                                    : theme.colorScheme.onSurface.withOpacity(0.3),
                              ),
                              onPressed: _isComposing && !widget.isLoading
                                  ? _handleSubmitted
                                  : null,
                              tooltip: 'Отправить',
                            ),
                          ).animate(
                            target: _isComposing ? 1 : 0,
                          ).scale(
                            begin: const Offset(0.8, 0.8),
                            end: const Offset(1.0, 1.0),
                            duration: 150.ms,
                            curve: Curves.easeOut,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // Вспомогательный метод для создания элемента меню вложений
  Widget _buildAttachOption({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: widget.isLoading ? null : onTap,
      borderRadius: BorderRadius.circular(12),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(
              icon,
              color: color,
              size: 22,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              fontSize: 12,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}
