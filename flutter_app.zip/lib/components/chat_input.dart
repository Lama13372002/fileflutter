import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as path;
import 'package:mime/mime.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:permission_handler/permission_handler.dart';

class ChatInput extends StatefulWidget {
  final Function(String message, {File? file}) onSendMessage;
  final bool isLoading;

  const ChatInput({
    Key? key,
    required this.onSendMessage,
    this.isLoading = false,
  }) : super(key: key);

  @override
  State<ChatInput> createState() => _ChatInputState();
}

class _ChatInputState extends State<ChatInput> {
  final TextEditingController _controller = TextEditingController();
  final FocusNode _focusNode = FocusNode();

  File? _selectedFile;
  String? _fileName;

  bool _showAttachMenu = false;

  bool get _isComposing => _controller.text.isNotEmpty || _selectedFile != null;

  @override
  void initState() {
    super.initState();
    // Добавляем простой слушатель для обновления UI при изменении текста
    _controller.addListener(() {
      setState(() {});
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  // Метод для переключения меню вложений
  void _toggleAttachMenu() {
    setState(() {
      _showAttachMenu = !_showAttachMenu;
    });
  }

  Future<void> _pickImage(ImageSource source) async {
    final hasPermission = await _requestPermission(
      source == ImageSource.camera
          ? Permission.camera
          : Permission.photos
    );

    if (!hasPermission) {
      return;
    }

    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(
      source: source,
      imageQuality: 70,
    );

    if (pickedFile != null) {
      setState(() {
        _selectedFile = File(pickedFile.path);
        _fileName = path.basename(pickedFile.path);
        _showAttachMenu = false; // Скрываем меню после выбора
      });
    }
  }

  Future<void> _pickFile() async {
    final hasPermission = await _requestPermission(Permission.storage);

    if (!hasPermission) {
      return;
    }

    final result = await FilePicker.platform.pickFiles(
      type: FileType.any,
      allowMultiple: false,
    );

    if (result != null && result.files.single.path != null) {
      setState(() {
        _selectedFile = File(result.files.single.path!);
        _fileName = result.files.single.name;
        _showAttachMenu = false; // Скрываем меню после выбора
      });
    }
  }

  Future<bool> _requestPermission(Permission permission) async {
    final status = await permission.status;

    if (status.isGranted) {
      return true;
    }

    if (status.isDenied) {
      final result = await permission.request();
      return result.isGranted;
    }

    if (status.isPermanentlyDenied) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text(
            'Приложению требуется доступ к хранилищу. Пожалуйста, разрешите доступ в настройках.'
          ),
          action: SnackBarAction(
            label: 'Настройки',
            onPressed: () => openAppSettings(),
          ),
        ),
      );
      return false;
    }

    return false;
  }

  void _clearSelectedFile() {
    setState(() {
      _selectedFile = null;
      _fileName = null;
    });
  }

  void _handleSubmitted() {
    final text = _controller.text.trim();

    if (text.isNotEmpty || _selectedFile != null) {
      widget.onSendMessage(text, file: _selectedFile);
      _controller.clear();
      _clearSelectedFile();
    }
  }

  String _getFileTypeIcon() {
    if (_selectedFile == null) return '';

    final fileExtension = path.extension(_selectedFile!.path).toLowerCase();
    final mimeType = lookupMimeType(_selectedFile!.path);

    if (mimeType?.startsWith('image/') ?? false) {
      return '🖼️';
    } else if (mimeType?.startsWith('video/') ?? false) {
      return '🎬';
    } else if (mimeType?.startsWith('audio/') ?? false) {
      return '🎵';
    } else if (fileExtension == '.pdf') {
      return '📄';
    } else if (fileExtension == '.doc' || fileExtension == '.docx') {
      return '📝';
    } else if (fileExtension == '.xls' || fileExtension == '.xlsx') {
      return '📊';
    } else if (fileExtension == '.ppt' || fileExtension == '.pptx') {
      return '📊';
    } else if (fileExtension == '.zip' || fileExtension == '.rar') {
      return '📦';
    }

    return '📎';
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Панель выбора вложений
        AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          height: _showAttachMenu ? 80 : 0,
          curve: Curves.easeInOut,
          color: theme.colorScheme.surface,
          child: SingleChildScrollView(
            physics: const NeverScrollableScrollPhysics(),
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _buildAttachOption(
                    icon: Icons.image,
                    label: 'Галерея',
                    color: Colors.blue,
                    onTap: () => _pickImage(ImageSource.gallery),
                  ),
                  _buildAttachOption(
                    icon: Icons.camera_alt,
                    label: 'Камера',
                    color: Colors.green,
                    onTap: () => _pickImage(ImageSource.camera),
                  ),
                  _buildAttachOption(
                    icon: Icons.insert_drive_file,
                    label: 'Документ',
                    color: Colors.orange,
                    onTap: _pickFile,
                  ),
                  _buildAttachOption(
                    icon: Icons.close,
                    label: 'Закрыть',
                    color: Colors.red,
                    onTap: _toggleAttachMenu,
                  ),
                ],
              ),
            ),
          ),
        ),

        // Выбранный файл
        if (_selectedFile != null)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
            margin: const EdgeInsets.only(bottom: 8.0, left: 12.0, right: 12.0),
            decoration: BoxDecoration(
              color: theme.colorScheme.secondaryContainer.withOpacity(0.5),
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: theme.shadowColor.withOpacity(0.1),
                  blurRadius: 4,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Row(
              children: [
                Text(_getFileTypeIcon(), style: const TextStyle(fontSize: 20)),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    _fileName ?? 'Файл',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: theme.colorScheme.onSecondaryContainer,
                    ),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.close, size: 18),
                  onPressed: _clearSelectedFile,
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                  color: theme.colorScheme.onSecondaryContainer,
                ),
              ],
            ),
          ).animate().slideY(
            begin: 1,
            end: 0,
            curve: Curves.easeOutQuad,
            duration: 250.ms,
          ),

        // Поле ввода
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 12.0),
          decoration: BoxDecoration(
            color: theme.colorScheme.surface,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: 4,
                offset: const Offset(0, -1),
              ),
            ],
          ),
          child: SafeArea(
            child: Row(
              children: [
                // Кнопка прикрепления файлов
                IconButton(
                  icon: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: _showAttachMenu
                          ? theme.colorScheme.primary.withOpacity(0.2)
                          : Colors.transparent,
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      Icons.add,
                      color: _showAttachMenu
                          ? theme.colorScheme.primary
                          : theme.colorScheme.onSurface.withOpacity(0.7),
                    ),
                  ),
                  onPressed: widget.isLoading ? null : _toggleAttachMenu,
                  tooltip: 'Прикрепить файл',
                ),

                // Поле ввода текста
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      color: theme.colorScheme.surfaceVariant.withOpacity(0.7),
                      borderRadius: const BorderRadius.all(Radius.circular(24)),
                      border: Border.all(
                        color: theme.colorScheme.outline.withOpacity(0.1),
                        width: 1,
                      ),
                    ),
                    child: Row(
                      children: [
                        // Небольшой отступ с левой стороны для лучшего внешнего вида
                        const SizedBox(width: 12),

                        Expanded(
                          child: ConstrainedBox(
                            constraints: const BoxConstraints(
                              minHeight: 40.0, // Минимальная высота поля
                              maxHeight: 100.0, // Ограничиваем максимальную высоту
                            ),
                            child: TextField(
                              // TextField может сам управлять скроллингом с maxLines > 1
                              controller: _controller,
                              focusNode: _focusNode,
                              decoration: InputDecoration(
                                hintText: 'Напишите сообщение...',
                                border: InputBorder.none,
                                isDense: true,
                                contentPadding: const EdgeInsets.symmetric(vertical: 12),
                                hintStyle: TextStyle(
                                  color: theme.colorScheme.onSurface.withOpacity(0.5),
                                ),
                              ),
                              textCapitalization: TextCapitalization.sentences,
                              enabled: !widget.isLoading,
                              maxLines: 6, // Ограничиваем количество строк, чтобы не заполнять весь экран
                              minLines: 1,
                              // Используем multiline для возможности скроллинга и более удобного ввода
                              keyboardType: TextInputType.multiline,
                              textInputAction: TextInputAction.newline,
                              style: TextStyle(
                                fontSize: 16.0, // Оптимальный размер для чтения
                              ),
                              onChanged: (text) {
                                setState(() {});
                              },
                              scrollPhysics: const ClampingScrollPhysics(), // Для предсказуемого поведения
                            ),
                          ),
                        ),

                        // Кнопка отправки
                        Padding(
                          padding: const EdgeInsets.only(right: 4.0),
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 200),
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              color: _isComposing
                                  ? theme.colorScheme.primary
                                  : theme.colorScheme.surfaceVariant,
                              shape: BoxShape.circle,
                            ),
                            child: IconButton(
                              icon: Icon(
                                Icons.send,
                                size: 20,
                                color: _isComposing
                                    ? theme.colorScheme.onPrimary
                                    : theme.colorScheme.onSurface.withOpacity(0.3),
                              ),
                              onPressed: _isComposing && !widget.isLoading
                                  ? _handleSubmitted
                                  : null,
                              tooltip: 'Отправить',
                            ),
                          ).animate(
                            target: _isComposing ? 1 : 0,
                          ).scale(
                            begin: const Offset(0.8, 0.8),
                            end: const Offset(1.0, 1.0),
                            duration: 150.ms,
                            curve: Curves.easeOut,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // Вспомогательный метод для создания элемента меню вложений
  Widget _buildAttachOption({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: widget.isLoading ? null : onTap,
      borderRadius: BorderRadius.circular(12),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(
              icon,
              color: color,
              size: 22,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              fontSize: 12,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}
