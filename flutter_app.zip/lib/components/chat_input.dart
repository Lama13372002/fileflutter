import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as path;
import 'package:mime/mime.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:permission_handler/permission_handler.dart';

class ChatInput extends StatefulWidget {
  final Function(String message, {File? file}) onSendMessage;
  final bool isLoading;

  const ChatInput({
    Key? key,
    required this.onSendMessage,
    this.isLoading = false,
  }) : super(key: key);

  @override
  State<ChatInput> createState() => _ChatInputState();
}

class _ChatInputState extends State<ChatInput> {
  final TextEditingController _controller = TextEditingController();
  final FocusNode _focusNode = FocusNode();

  File? _selectedFile;
  String? _fileName;

  bool get _isComposing => _controller.text.isNotEmpty || _selectedFile != null;

  @override
  void dispose() {
    _controller.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  Future<void> _pickImage(ImageSource source) async {
    final hasPermission = await _requestPermission(
      source == ImageSource.camera
          ? Permission.camera
          : Permission.photos
    );

    if (!hasPermission) {
      return;
    }

    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(
      source: source,
      imageQuality: 70,
    );

    if (pickedFile != null) {
      setState(() {
        _selectedFile = File(pickedFile.path);
        _fileName = path.basename(pickedFile.path);
      });
    }
  }

  Future<void> _pickFile() async {
    final hasPermission = await _requestPermission(Permission.storage);

    if (!hasPermission) {
      return;
    }

    final result = await FilePicker.platform.pickFiles(
      type: FileType.any,
      allowMultiple: false,
    );

    if (result != null && result.files.single.path != null) {
      setState(() {
        _selectedFile = File(result.files.single.path!);
        _fileName = result.files.single.name;
      });
    }
  }

  Future<bool> _requestPermission(Permission permission) async {
    final status = await permission.status;

    if (status.isGranted) {
      return true;
    }

    if (status.isDenied) {
      final result = await permission.request();
      return result.isGranted;
    }

    if (status.isPermanentlyDenied) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text(
            'Приложению требуется доступ к хранилищу. Пожалуйста, разрешите доступ в настройках.'
          ),
          action: SnackBarAction(
            label: 'Настройки',
            onPressed: () => openAppSettings(),
          ),
        ),
      );
      return false;
    }

    return false;
  }

  void _clearSelectedFile() {
    setState(() {
      _selectedFile = null;
      _fileName = null;
    });
  }

  void _handleSubmitted() {
    final text = _controller.text.trim();

    if (text.isNotEmpty || _selectedFile != null) {
      widget.onSendMessage(text, file: _selectedFile);
      _controller.clear();
      _clearSelectedFile();
    }
  }

  String _getFileTypeIcon() {
    if (_selectedFile == null) return '';

    final fileExtension = path.extension(_selectedFile!.path).toLowerCase();
    final mimeType = lookupMimeType(_selectedFile!.path);

    if (mimeType?.startsWith('image/') ?? false) {
      return '🖼️';
    } else if (mimeType?.startsWith('video/') ?? false) {
      return '🎬';
    } else if (mimeType?.startsWith('audio/') ?? false) {
      return '🎵';
    } else if (fileExtension == '.pdf') {
      return '📄';
    } else if (fileExtension == '.doc' || fileExtension == '.docx') {
      return '📝';
    } else if (fileExtension == '.xls' || fileExtension == '.xlsx') {
      return '📊';
    } else if (fileExtension == '.ppt' || fileExtension == '.pptx') {
      return '📊';
    } else if (fileExtension == '.zip' || fileExtension == '.rar') {
      return '📦';
    }

    return '📎';
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 12.0),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 4,
            offset: const Offset(0, -1),
          ),
        ],
      ),
      child: SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (_selectedFile != null)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                margin: const EdgeInsets.only(bottom: 8.0),
                decoration: BoxDecoration(
                  color: theme.colorScheme.secondaryContainer.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    Text(_getFileTypeIcon(), style: const TextStyle(fontSize: 20)),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        _fileName ?? 'Файл',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close, size: 20),
                      onPressed: _clearSelectedFile,
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(),
                    ),
                  ],
                ),
              ).animate().slideY(
                begin: 1,
                end: 0,
                curve: Curves.easeOutQuad,
                duration: 250.ms,
              ),

            Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.attach_file),
                  onPressed: widget.isLoading ? null : _pickFile,
                  tooltip: 'Прикрепить файл',
                ),
                IconButton(
                  icon: const Icon(Icons.photo),
                  onPressed: widget.isLoading
                      ? null
                      : () => _pickImage(ImageSource.gallery),
                  tooltip: 'Прикрепить изображение',
                ),
                IconButton(
                  icon: const Icon(Icons.camera_alt),
                  onPressed: widget.isLoading
                      ? null
                      : () => _pickImage(ImageSource.camera),
                  tooltip: 'Сделать фото',
                ),
                Expanded(
                  child: TextField(
                    controller: _controller,
                    focusNode: _focusNode,
                    decoration: InputDecoration(
                      hintText: 'Напишите сообщение...',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(24),
                        borderSide: BorderSide.none,
                      ),
                      filled: true,
                      fillColor: theme.colorScheme.surfaceVariant,
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 10,
                      ),
                    ),
                    textCapitalization: TextCapitalization.sentences,
                    enabled: !widget.isLoading,
                    maxLines: null,
                    keyboardType: TextInputType.multiline,
                    textInputAction: TextInputAction.newline,
                    onChanged: (text) {
                      setState(() {});
                    },
                  ),
                ),
                AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  width: _isComposing ? 48 : 0,
                  child: _isComposing
                      ? IconButton(
                          icon: const Icon(Icons.send),
                          onPressed: widget.isLoading ? null : _handleSubmitted,
                          color: theme.colorScheme.primary,
                        )
                      : null,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
