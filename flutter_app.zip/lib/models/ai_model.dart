import 'package:flutter/material.dart';

enum AIModelType {
  gemini,
  qwen,
  gpt4mini,
  deepseekv3,
  deepseekr1,
  llama4maverick,
}

class AIModel {
  final String id;
  final String name;
  final String description;
  final AIModelType type;
  final Color color;
  final IconData icon;
  final String? logoAsset; // Добавлено поле для хранения пути к логотипу
  final bool supportsImageAnalysis; // Поддержка анализа изображений
  final bool supportsFileAnalysis; // Поддержка анализа файлов

  const AIModel({
    required this.id,
    required this.name,
    required this.description,
    required this.type,
    required this.color,
    required this.icon,
    this.logoAsset, // Необязательный параметр для логотипа
    this.supportsImageAnalysis = false, // По умолчанию не поддерживает
    this.supportsFileAnalysis = false, // По умолчанию не поддерживает
  });

  static const AIModel gemini = AIModel(
    id: 'gemini-2.5-flash-preview-05-20',
    name: 'Gemini 2.5 Flash',
    description: 'Быстрая и эффективная модель от Google',
    type: AIModelType.gemini,
    color: Colors.blue,
    icon: Icons.auto_awesome,
    logoAsset: 'assets/images/gemini_logo.png',
    supportsImageAnalysis: true, // Поддерживает анализ изображений
    supportsFileAnalysis: true, // Поддерживает анализ файлов
  );

  static const AIModel qwen = AIModel(
    id: 'qwen3-235b-a22b',
    name: 'Qwen3-235b-a22b',
    description: 'Продвинутая модель Qwen от Alibaba Cloud',
    type: AIModelType.qwen,
    color: Colors.amber, // Изменено с orange на amber для лучшей видимости
    icon: Icons.cloud_done,
    logoAsset: 'assets/images/qwen_logo.png',
    supportsImageAnalysis: false,
    supportsFileAnalysis: false,
  );

  static const AIModel gpt4mini = AIModel(
    id: 'gpt-4.1-mini-2025-04-14',
    name: 'GPT-4.1-mini',
    description: 'Компактная версия GPT-4.1 с высокой эффективностью',
    type: AIModelType.gpt4mini,
    color: Colors.lightGreen, // Изменено с green на lightGreen для лучшей контрастности
    icon: Icons.smart_toy,
    logoAsset: 'assets/images/openai_logo.png',
    supportsImageAnalysis: true, // Поддерживает анализ изображений
    supportsFileAnalysis: true, // Поддерживает анализ файлов
  );

  static const AIModel deepseekv3 = AIModel(
    id: 'deepseek-v3',
    name: 'Deepseek v3',
    description: 'Продвинутая модель Deepseek версии 3',
    type: AIModelType.deepseekv3,
    color: Colors.blueGrey,
    icon: Icons.trending_up,
    logoAsset: 'assets/images/deepseek_logo.png',
    supportsImageAnalysis: false,
    supportsFileAnalysis: false,
  );

  static const AIModel deepseekr1 = AIModel(
    id: 'deepseek-r1',
    name: 'Deepseek-r1',
    description: 'Модель Deepseek с расширенными возможностями рассуждения',
    type: AIModelType.deepseekr1,
    color: Colors.indigo,
    icon: Icons.psychology_alt,
    logoAsset: 'assets/images/deepseek_logo.png',
    supportsImageAnalysis: false,
    supportsFileAnalysis: false,
  );

  static const AIModel llama4maverick = AIModel(
    id: 'llama-4-maverick',
    name: 'llama-4-maverick',
    description: 'Инновационная модель llama 4 с передовыми возможностями',
    type: AIModelType.llama4maverick,
    color: Colors.purpleAccent, // Изменено с deepPurple на purpleAccent для лучшей видимости
    icon: Icons.token,
    logoAsset: 'assets/images/llama_logo.png',
    supportsImageAnalysis: false,
    supportsFileAnalysis: false,
  );

  static List<AIModel> getAvailableModels() {
    return [
      gemini,
      qwen,
      gpt4mini,
      deepseekv3,
      deepseekr1,
      llama4maverick,
    ];
  }

  // Вспомогательный метод для получения списка моделей, поддерживающих анализ изображений
  static List<AIModel> getModelsWithImageAnalysis() {
    return getAvailableModels().where((model) => model.supportsImageAnalysis).toList();
  }

  // Вспомогательный метод для получения списка моделей, поддерживающих анализ файлов
  static List<AIModel> getModelsWithFileAnalysis() {
    return getAvailableModels().where((model) => model.supportsFileAnalysis).toList();
  }
}
