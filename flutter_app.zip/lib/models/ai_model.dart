import 'package:flutter/material.dart';

enum AIModelType {
  gemini,
  claude,
}

class AIModel {
  final String id;
  final String name;
  final String description;
  final AIModelType type;
  final Color color;
  final IconData icon;

  const AIModel({
    required this.id,
    required this.name,
    required this.description,
    required this.type,
    required this.color,
    required this.icon,
  });

  static const AIModel gemini = AIModel(
    id: 'gemini-2.5-flash-preview-05-20',
    name: 'Gemini 2.5 Flash',
    description: 'Быстрая и эффективная модель от Google',
    type: AIModelType.gemini,
    color: Colors.blue,
    icon: Icons.auto_awesome,
  );

  static const AIModel claude = AIModel(
    id: 'claude-3-7-sonnet-20250219',
    name: 'Claude 3.7 Sonnet',
    description: 'Мощная модель от Anthropic',
    type: AIModelType.claude,
    color: Colors.purple,
    icon: Icons.psychology,
  );

  static List<AIModel> getAvailableModels() {
    return [gemini, claude];
  }
}