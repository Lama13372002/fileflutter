import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';

enum MessageType {
  text,
  image,
  file,
  audio,
  video,
}

enum MessageRole {
  user,
  assistant,
  system,
}

class Message {
  final String id;
  final MessageType type;
  final MessageRole role;
  final String content;
  final DateTime timestamp;
  final File? file;
  final Uint8List? fileData;
  final String? fileName;
  final String? mimeType;
  final bool isLoading;

  Message({
    String? id,
    required this.type,
    required this.role,
    required this.content,
    DateTime? timestamp,
    this.file,
    this.fileData,
    this.fileName,
    this.mimeType,
    this.isLoading = false,
  }) :
    id = id ?? const Uuid().v4(),
    timestamp = timestamp ?? DateTime.now();

  Message copyWith({
    String? id,
    MessageType? type,
    MessageRole? role,
    String? content,
    DateTime? timestamp,
    File? file,
    Uint8List? fileData,
    String? fileName,
    String? mimeType,
    bool? isLoading,
  }) {
    return Message(
      id: id ?? this.id,
      type: type ?? this.type,
      role: role ?? this.role,
      content: content ?? this.content,
      timestamp: timestamp ?? this.timestamp,
      file: file ?? this.file,
      fileData: fileData ?? this.fileData,
      fileName: fileName ?? this.fileName,
      mimeType: mimeType ?? this.mimeType,
      isLoading: isLoading ?? this.isLoading,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'role': role.toString().split('.').last,
      'content': content,
    };
  }

  @override
  String toString() {
    return 'Message(id: $id, type: $type, role: $role, content: $content, timestamp: $timestamp)';
  }
}
