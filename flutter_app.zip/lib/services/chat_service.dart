import 'dart:io';
import 'dart:async';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as path;
import 'package:uuid/uuid.dart';
import '../models/message.dart';
import '../models/ai_model.dart';

class Chat {
  final String id;
  final String title;
  final List<Message> messages;
  final DateTime createdAt;
  final DateTime updatedAt;
  final AIModel aiModel;

  Chat({
    String? id,
    required this.title,
    List<Message>? messages,
    DateTime? createdAt,
    DateTime? updatedAt,
    required this.aiModel,
  }) :
    id = id ?? const Uuid().v4(),
    messages = messages ?? [],
    createdAt = createdAt ?? DateTime.now(),
    updatedAt = updatedAt ?? DateTime.now();

  Chat copyWith({
    String? id,
    String? title,
    List<Message>? messages,
    DateTime? createdAt,
    DateTime? updatedAt,
    AIModel? aiModel,
  }) {
    return Chat(
      id: id ?? this.id,
      title: title ?? this.title,
      messages: messages ?? this.messages,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      aiModel: aiModel ?? this.aiModel,
    );
  }

  // Вспомогательный метод для создания превью чата
  String get preview {
    if (messages.isEmpty) {
      return 'Новый чат';
    }

    // Ищем последнее сообщение от пользователя
    final userMessages = messages.where((msg) => msg.role == MessageRole.user);
    if (userMessages.isEmpty) {
      return 'Новый чат';
    }

    return userMessages.last.content.length > 30
        ? '${userMessages.last.content.substring(0, 30)}...'
        : userMessages.last.content;
  }
}

class ChatService extends ChangeNotifier {
  // Список чатов
  final List<Chat> _chats = [];

  // Текущий активный чат
  String? _currentChatId;

  // Геттеры
  List<Chat> get chats => List.unmodifiable(_chats);

  Chat? get currentChat {
    if (_currentChatId == null) return null;
    return _chats.firstWhere((chat) => chat.id == _currentChatId,
                            orElse: () => createNewChat());
  }

  List<Message> get messages {
    if (currentChat == null) return [];
    return List.unmodifiable(currentChat!.messages);
  }

  // Создание нового чата
  Chat createNewChat({AIModel aiModel = AIModel.gemini}) {
    final newChat = Chat(
      title: 'Новый чат',
      aiModel: aiModel
    );

    _chats.add(newChat);
    _currentChatId = newChat.id;
    notifyListeners();
    return newChat;
  }

  // Удаление чата
  void deleteChat(String chatId) {
    _chats.removeWhere((chat) => chat.id == chatId);

    // Если удалили текущий чат, выбираем другой или создаем новый
    if (_currentChatId == chatId) {
      if (_chats.isNotEmpty) {
        _currentChatId = _chats.first.id;
      } else {
        createNewChat();
      }
    }

    notifyListeners();
  }

  // Выбор активного чата
  void selectChat(String chatId) {
    if (_chats.any((chat) => chat.id == chatId)) {
      _currentChatId = chatId;
      notifyListeners();
    }
  }

  // Переименование чата
  void renameChat(String chatId, String newTitle) {
    final index = _chats.indexWhere((chat) => chat.id == chatId);
    if (index != -1) {
      final chat = _chats[index];
      _chats[index] = chat.copyWith(
        title: newTitle,
        updatedAt: DateTime.now(),
      );
      notifyListeners();
    }
  }

  // Смена модели ИИ для чата
  void changeChatModel(String chatId, AIModel newModel) {
    final index = _chats.indexWhere((chat) => chat.id == chatId);
    if (index != -1) {
      final chat = _chats[index];
      _chats[index] = chat.copyWith(
        aiModel: newModel,
        updatedAt: DateTime.now(),
      );
      notifyListeners();
    }
  }

  // Добавление сообщения от пользователя
  void addUserMessage({
    required String content,
    File? file,
    Uint8List? fileData,
    String? fileName,
    String? mimeType,
  }) {
    // Если нет активного чата, создаем новый
    if (currentChat == null) {
      createNewChat();
    }

    MessageType type = MessageType.text;

    if (file != null || fileData != null) {
      final fileExt = file != null
          ? path.extension(file.path).toLowerCase()
          : fileName != null ? path.extension(fileName).toLowerCase() : '';

      if (fileExt == '.jpg' || fileExt == '.jpeg' || fileExt == '.png' || fileExt == '.gif') {
        type = MessageType.image;
      } else if (fileExt == '.mp3' || fileExt == '.wav' || fileExt == '.m4a') {
        type = MessageType.audio;
      } else if (fileExt == '.mp4' || fileExt == '.mov' || fileExt == '.avi') {
        type = MessageType.video;
      } else {
        type = MessageType.file;
      }
    }

    final message = Message(
      type: type,
      role: MessageRole.user,
      content: content,
      file: file,
      fileData: fileData,
      fileName: fileName,
      mimeType: mimeType,
    );

    final chatIndex = _chats.indexWhere((chat) => chat.id == _currentChatId);
    if (chatIndex != -1) {
      final chat = _chats[chatIndex];
      final updatedMessages = List<Message>.from(chat.messages)..add(message);

      _chats[chatIndex] = chat.copyWith(
        messages: updatedMessages,
        updatedAt: DateTime.now(),
        title: content.length > 30 ? content.substring(0, 30) + '...' : content,
      );

      notifyListeners();
    }
  }

  // Добавление сообщения от ассистента
  void addAssistantMessage({
    required String content,
    bool isLoading = false,
  }) {
    if (currentChat == null) {
      createNewChat();
    }

    final message = Message(
      type: MessageType.text,
      role: MessageRole.assistant,
      content: content,
      isLoading: isLoading,
    );

    final chatIndex = _chats.indexWhere((chat) => chat.id == _currentChatId);
    if (chatIndex != -1) {
      final chat = _chats[chatIndex];
      final updatedMessages = List<Message>.from(chat.messages)..add(message);

      _chats[chatIndex] = chat.copyWith(
        messages: updatedMessages,
        updatedAt: DateTime.now(),
      );

      notifyListeners();
    }
  }

  // Создание сообщения с состоянием загрузки
  Message createLoadingMessage() {
    return Message(
      type: MessageType.text,
      role: MessageRole.assistant,
      content: '',
      isLoading: true,
    );
  }

  // Обновление последнего сообщения
  void updateLastMessage({
    String? content,
    bool? isLoading,
  }) {
    if (currentChat == null || currentChat!.messages.isEmpty) return;

    final chatIndex = _chats.indexWhere((chat) => chat.id == _currentChatId);
    if (chatIndex != -1) {
      final chat = _chats[chatIndex];
      final messages = List<Message>.from(chat.messages);

      final lastMessage = messages.last;
      final updatedMessage = lastMessage.copyWith(
        content: content ?? lastMessage.content,
        isLoading: isLoading ?? lastMessage.isLoading,
      );

      messages[messages.length - 1] = updatedMessage;

      _chats[chatIndex] = chat.copyWith(
        messages: messages,
        updatedAt: DateTime.now(),
      );

      notifyListeners();
    }
  }

  // Обновление сообщения по id
  void updateMessage({
    required String messageId,
    String? content,
    bool? isLoading,
  }) {
    if (currentChat == null) return;

    final chatIndex = _chats.indexWhere((chat) => chat.id == _currentChatId);
    if (chatIndex != -1) {
      final chat = _chats[chatIndex];
      final messages = List<Message>.from(chat.messages);

      final messageIndex = messages.indexWhere((msg) => msg.id == messageId);
      if (messageIndex != -1) {
        final message = messages[messageIndex];
        final updatedMessage = message.copyWith(
          content: content ?? message.content,
          isLoading: isLoading ?? message.isLoading,
        );

        messages[messageIndex] = updatedMessage;

        _chats[chatIndex] = chat.copyWith(
          messages: messages,
          updatedAt: DateTime.now(),
        );

        notifyListeners();
      }
    }
  }

  // Конвертация сообщений в формат для API
  List<Map<String, dynamic>> getMessagesForApi() {
    if (currentChat == null) return [];

    return currentChat!.messages
        .where((msg) => !msg.isLoading)
        .map((msg) => msg.toMap())
        .toList();
  }

  // Очистка истории текущего чата
  void clearCurrentChat() {
    if (currentChat == null) return;

    final chatIndex = _chats.indexWhere((chat) => chat.id == _currentChatId);
    if (chatIndex != -1) {
      final chat = _chats[chatIndex];

      _chats[chatIndex] = chat.copyWith(
        messages: [],
        updatedAt: DateTime.now(),
        title: 'Новый чат',
      );

      notifyListeners();
    }
  }

  // Добавление системного сообщения
  void addSystemMessage({required String content}) {
    if (currentChat == null) {
      createNewChat();
    }

    final message = Message(
      type: MessageType.text,
      role: MessageRole.system,
      content: content,
    );

    final chatIndex = _chats.indexWhere((chat) => chat.id == _currentChatId);
    if (chatIndex != -1) {
      final chat = _chats[chatIndex];
      final updatedMessages = List<Message>.from(chat.messages)..add(message);

      _chats[chatIndex] = chat.copyWith(
        messages: updatedMessages,
        updatedAt: DateTime.now(),
      );

      notifyListeners();
    }
  }

  // Инициализация сервиса при запуске
  void initialize() {
    if (_chats.isEmpty) {
      createNewChat();
    }
  }
}
