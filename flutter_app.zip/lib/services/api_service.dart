import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

class ApiService extends ChangeNotifier {
  static const String baseUrl = 'https://api.cometapi.com';
  static const String apiVersion = 'v1';

  // ВАЖНО: Замените это значение на ваш API ключ от CometAPI
  static const String _defaultApiKey = 'sk-yciCPktGC4LLNjMJwhpZGag9h16BVmaLjvpC68NuxmmbowHZ';

  String _apiKey = _defaultApiKey;
  bool _isReady = false;

  bool get isReady => _isReady;

  ApiService() {
    // Автоматическая инициализация при создании сервиса
    _init();
  }

  void _init() {
    _isReady = true;
    notifyListeners();
  }

  // Этот метод оставлен для совместимости, но обычно API ключ будет браться из константы
  Future<void> initialize({String? apiKey}) async {
    if (apiKey != null && apiKey.isNotEmpty) {
      _apiKey = apiKey;
    }
    _isReady = true;
    notifyListeners();
  }

  // Тестовый метод для проверки соединения с API
  Future<bool> testConnection() async {
    try {
      final endpoint = '$baseUrl/$apiVersion/models';
      final headers = {
        'Authorization': 'Bearer $_apiKey',
      };

      debugPrint('Тестирование соединения с API: $endpoint');

      final response = await http.get(
        Uri.parse(endpoint),
        headers: headers,
      ).timeout(const Duration(seconds: 10));

      debugPrint('Статус ответа: ${response.statusCode}');
      debugPrint('Тело ответа: ${response.body}');

      return response.statusCode >= 200 && response.statusCode < 300;
    } catch (e) {
      debugPrint('Ошибка при тестировании соединения: $e');
      return false;
    }
  }

  Future<Map<String, dynamic>> chatCompletion({
    required String prompt,
    List<Map<String, dynamic>>? history,
    double temperature = 0.7,
    int maxTokens = 1024,
  }) async {
    if (!_isReady) {
      throw Exception('API service not initialized');
    }

    final endpoint = '$baseUrl/$apiVersion/chat/completions';

    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $_apiKey',
    };

    final messages = <Map<String, dynamic>>[];

    // Добавляем историю, если она есть
    if (history != null && history.isNotEmpty) {
      messages.addAll(history);
    }

    // Добавляем текущее сообщение пользователя
    messages.add({
      'role': 'user',
      'content': prompt,
    });

    final body = jsonEncode({
      'model': 'gemini-2.5-flash-preview-05-20', // Изменено: корректное название модели
      'messages': messages,
      'temperature': temperature,
      'max_tokens': maxTokens,
    });

    try {
      debugPrint('Отправка запроса к $endpoint');
      debugPrint('Заголовки: $headers');
      debugPrint('Тело запроса: $body');

      final response = await http.post(
        Uri.parse(endpoint),
        headers: headers,
        body: body,
      ).timeout(const Duration(seconds: 30)); // Увеличен таймаут до 30 секунд

      debugPrint('Статус ответа: ${response.statusCode}');
      debugPrint('Тело ответа: ${response.body}');

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception('Failed to get response: ${response.statusCode}: ${response.body}');
      }
    } catch (e) {
      debugPrint('Error during API call: $e');
      throw Exception('Error during API call: $e');
    }
  }

  Future<Map<String, dynamic>> chatCompletionWithFile({
    required String prompt,
    required Uint8List fileData,
    required String fileName,
    required String mimeType,
    List<Map<String, dynamic>>? history,
    double temperature = 0.7,
    int maxTokens = 1024,
  }) async {
    if (!_isReady) {
      throw Exception('API service not initialized');
    }

    final endpoint = '$baseUrl/$apiVersion/chat/completions';

    var request = http.MultipartRequest('POST', Uri.parse(endpoint));

    request.headers.addAll({
      'Authorization': 'Bearer $_apiKey',
    });

    final messages = <Map<String, dynamic>>[];

    // Добавляем историю, если она есть
    if (history != null && history.isNotEmpty) {
      messages.addAll(history);
    }

    // Добавляем файл как multipart
    final fileField = http.MultipartFile.fromBytes(
      'file',
      fileData,
      filename: fileName,
    );

    request.files.add(fileField);

    // Добавляем текстовые поля
    request.fields['model'] = 'gemini-2.5-flash-preview-05-20'; // Изменено: корректное название модели
    request.fields['prompt'] = prompt;
    request.fields['temperature'] = temperature.toString();
    request.fields['max_tokens'] = maxTokens.toString();

    try {
      debugPrint('Отправка запроса с файлом к $endpoint');
      debugPrint('Заголовки: ${request.headers}');

      final streamedResponse = await request.send()
          .timeout(const Duration(seconds: 30)); // Увеличен таймаут
      final response = await http.Response.fromStream(streamedResponse);

      debugPrint('Статус ответа: ${response.statusCode}');
      debugPrint('Тело ответа: ${response.body}');

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception('Failed to get response: ${response.statusCode}: ${response.body}');
      }
    } catch (e) {
      debugPrint('Error during API call with file: $e');
      throw Exception('Error during API call: $e');
    }
  }

  // Метод для потоковой передачи ответов через HTTP вместо WebSocket
  Stream<String> streamChatCompletion({
    required String prompt,
    List<Map<String, dynamic>>? history,
    double temperature = 0.7,
    int maxTokens = 8192, // Увеличенное значение для максимального количества токенов
  }) {
    if (!_isReady) {
      throw Exception('API service not initialized');
    }

    // Используем контроллер с broadcast, чтобы несколько слушателей могли получать данные
    final streamController = StreamController<String>.broadcast();

    final endpoint = '$baseUrl/$apiVersion/chat/completions';

    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $_apiKey',
      'Accept': 'text/event-stream', // Важно для SSE (Server-Sent Events)
    };

    final messages = <Map<String, dynamic>>[];

    // Добавляем историю, если она есть
    if (history != null && history.isNotEmpty) {
      messages.addAll(history);
    }

    // Добавляем текущее сообщение пользователя
    messages.add({
      'role': 'user',
      'content': prompt,
    });

    final body = jsonEncode({
      'model': 'gemini-2.5-flash-preview-05-20', // Точное название модели
      'messages': messages,
      'temperature': temperature,
      'max_tokens': maxTokens,
      'stream': true, // Важный параметр для включения стриминга
    });

    debugPrint('Отправка HTTP запроса для стриминга: $endpoint');
    debugPrint('Заголовки: $headers');
    debugPrint('Тело запроса: $body');

    _streamHttpRequest(
      url: endpoint,
      headers: headers,
      body: body,
      onData: (chunk) {
        // Обрабатываем полученный фрагмент данных
        if (chunk.trim().isNotEmpty) {
          debugPrint('Получен пакет данных размером ${chunk.length} байт: ${chunk.substring(0, chunk.length > 50 ? 50 : chunk.length)}...');

          try {
            // SSE формат данных начинается с 'data: '
            if (chunk.startsWith('data: ')) {
              final jsonStr = chunk.substring(6).trim();

              // Стриминг может завершиться специальным маркером
              if (jsonStr == '[DONE]') {
                debugPrint('Получен маркер завершения стрима [DONE]');
                return;
              }

              debugPrint('Декодирование JSON данных');

              final jsonData = jsonDecode(jsonStr);

              // Проверяем структуру данных в соответствии с API CometAPI
              if (jsonData.containsKey('choices') &&
                  jsonData['choices'].isNotEmpty &&
                  jsonData['choices'][0].containsKey('delta') &&
                  jsonData['choices'][0]['delta'].containsKey('content')) {
                final content = jsonData['choices'][0]['delta']['content'];
                if (content != null) {
                  debugPrint('Контент: $content');
                  streamController.add(content);
                } else {
                  debugPrint('Контент пуст');
                }
              } else if (jsonData.containsKey('error')) {
                // Обработка ошибок от API
                final errorMessage = jsonData['error']['message'] ?? 'Unknown error';
                debugPrint('Ошибка от API: $errorMessage');
                streamController.addError(Exception('API error: $errorMessage'));
                streamController.close();
              } else {
                // Данные получены, но не соответствуют ожидаемой структуре
                debugPrint('Неизвестный формат данных: $jsonData');
              }
            } else {
              // Логирование неизвестного формата ответа
              debugPrint('Получены данные в неизвестном формате: $chunk');
            }
          } catch (e) {
            debugPrint('Ошибка при обработке фрагмента данных: $e');
            debugPrint('Необработанный фрагмент: $chunk');
            // Пытаемся продолжить обработку потока несмотря на ошибку
          }
        }
      },
      onDone: () {
        debugPrint('Поток данных завершен');
        if (!streamController.isClosed) {
          streamController.close();
        }
      },
      onError: (error) {
        debugPrint('Ошибка в потоке данных: $error');
        if (!streamController.isClosed) {
          streamController.addError(error);
          streamController.close();
        }
      },
    );

    return streamController.stream;
  }

  // Вспомогательный метод для HTTP запроса с потоковой обработкой
  void _streamHttpRequest({
    required String url,
    required Map<String, String> headers,
    required String body,
    required Function(String) onData,
    required Function() onDone,
    required Function(dynamic) onError,
  }) async {
    try {
      final client = http.Client();
      final request = http.Request('POST', Uri.parse(url));
      request.headers.addAll(headers);
      request.body = body;

      // Устанавливаем более длительный таймаут для запроса
      debugPrint('Отправка потокового запроса...');
      final response = await client.send(request)
          .timeout(const Duration(seconds: 60)); // Увеличенный таймаут для стрима

      debugPrint('Получен ответ со статусом: ${response.statusCode}');

      if (response.statusCode != 200) {
        final responseBody = await response.stream.bytesToString();
        debugPrint('HTTP ошибка: ${response.statusCode} - $responseBody');
        onError(Exception('HTTP error ${response.statusCode}: $responseBody'));
        return;
      }

      debugPrint('Начало обработки потока данных');

      // Обрабатываем поток данных построчно
      response.stream
          .transform(utf8.decoder)
          .transform(const LineSplitter())
          .listen(
        (dataChunk) {
          debugPrint('Получена часть потока размером ${dataChunk.length} байт');
          onData(dataChunk);
        },
        onDone: () {
          debugPrint('Поток данных завершен на уровне HTTP клиента');
          client.close();
          onDone();
        },
        onError: (e) {
          debugPrint('Ошибка при чтении потока: $e');
          client.close();
          onError(e);
        },
        cancelOnError: false, // Не отменяем подписку при ошибке
      );
    } catch (e) {
      debugPrint('Ошибка при выполнении HTTP-запроса: $e');
      onError(e);
    }
  }
}
