import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:web_socket_channel/web_socket_channel.dart';

class ApiService extends ChangeNotifier {
  static const String baseUrl = 'https://api.cometapi.com';
  static const String apiVersion = 'v1';

  // ВАЖНО: Замените это значение на ваш API ключ от CometAPI
  static const String _defaultApiKey = 'sk-yciCPktGC4LLNjMJwhpZGag9h16BVmaLjvpC68NuxmmbowHZ';

  String _apiKey = _defaultApiKey;
  bool _isReady = false;

  bool get isReady => _isReady;

  ApiService() {
    // Автоматическая инициализация при создании сервиса
    _init();
  }

  void _init() {
    _isReady = true;
    notifyListeners();
  }

  // Этот метод оставлен для совместимости, но обычно API ключ будет браться из константы
  Future<void> initialize({String? apiKey}) async {
    if (apiKey != null && apiKey.isNotEmpty) {
      _apiKey = apiKey;
    }
    _isReady = true;
    notifyListeners();
  }

  Future<Map<String, dynamic>> chatCompletion({
    required String prompt,
    List<Map<String, dynamic>>? history,
    double temperature = 0.7,
    int maxTokens = 1024,
  }) async {
    if (!_isReady) {
      throw Exception('API service not initialized');
    }

    final endpoint = '$baseUrl/$apiVersion/chat/completions';

    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $_apiKey',
    };

    final messages = <Map<String, dynamic>>[];

    // Добавляем историю, если она есть
    if (history != null && history.isNotEmpty) {
      messages.addAll(history);
    }

    // Добавляем текущее сообщение пользователя
    messages.add({
      'role': 'user',
      'content': prompt,
    });

    final body = jsonEncode({
      'model': 'gemini-2.5-flash-preview-04-17',
      'messages': messages,
      'temperature': temperature,
      'max_tokens': maxTokens,
    });

    try {
      final response = await http.post(
        Uri.parse(endpoint),
        headers: headers,
        body: body,
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception('Failed to get response: ${response.body}');
      }
    } catch (e) {
      throw Exception('Error during API call: $e');
    }
  }

  Future<Map<String, dynamic>> chatCompletionWithFile({
    required String prompt,
    required Uint8List fileData,
    required String fileName,
    required String mimeType,
    List<Map<String, dynamic>>? history,
    double temperature = 0.7,
    int maxTokens = 1024,
  }) async {
    if (!_isReady) {
      throw Exception('API service not initialized');
    }

    final endpoint = '$baseUrl/$apiVersion/chat/completions';

    var request = http.MultipartRequest('POST', Uri.parse(endpoint));

    request.headers.addAll({
      'Authorization': 'Bearer $_apiKey',
    });

    final messages = <Map<String, dynamic>>[];

    // Добавляем историю, если она есть
    if (history != null && history.isNotEmpty) {
      messages.addAll(history);
    }

    // Добавляем файл как multipart
    final fileField = http.MultipartFile.fromBytes(
      'file',
      fileData,
      filename: fileName,
    );

    request.files.add(fileField);

    // Добавляем текстовые поля
    request.fields['model'] = 'gemini-2.5-flash-preview-04-17';
    request.fields['prompt'] = prompt;
    request.fields['temperature'] = temperature.toString();
    request.fields['max_tokens'] = maxTokens.toString();

    try {
      final streamedResponse = await request.send();
      final response = await http.Response.fromStream(streamedResponse);

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception('Failed to get response: ${response.body}');
      }
    } catch (e) {
      throw Exception('Error during API call: $e');
    }
  }

  Stream<String> streamChatCompletion({
    required String prompt,
    List<Map<String, dynamic>>? history,
    double temperature = 0.7,
    int maxTokens = 1024,
  }) {
    if (!_isReady) {
      throw Exception('API service not initialized');
    }

    final streamController = StreamController<String>();

    final wsUrl = Uri.parse('wss://api.cometapi.com/$apiVersion/chat/completions/stream')
        .replace(queryParameters: {
      'api_key': _apiKey,
    });

    final channel = WebSocketChannel.connect(wsUrl);

    final messages = <Map<String, dynamic>>[];

    // Добавляем историю, если она есть
    if (history != null && history.isNotEmpty) {
      messages.addAll(history);
    }

    // Добавляем текущее сообщение пользователя
    messages.add({
      'role': 'user',
      'content': prompt,
    });

    final body = jsonEncode({
      'model': 'gemini-2.5-flash-preview-04-17',
      'messages': messages,
      'temperature': temperature,
      'max_tokens': maxTokens,
      'stream': true,
    });

    channel.sink.add(body);

    channel.stream.listen(
      (data) {
        final jsonData = jsonDecode(data);

        if (jsonData.containsKey('choices') &&
            jsonData['choices'].isNotEmpty &&
            jsonData['choices'][0].containsKey('delta') &&
            jsonData['choices'][0]['delta'].containsKey('content')) {
          final content = jsonData['choices'][0]['delta']['content'];
          streamController.add(content);
        }

        if (jsonData.containsKey('done') && jsonData['done'] == true) {
          streamController.close();
          channel.sink.close();
        }
      },
      onDone: () {
        if (!streamController.isClosed) {
          streamController.close();
        }
      },
      onError: (error) {
        streamController.addError(error);
        streamController.close();
        channel.sink.close();
      },
    );

    return streamController.stream;
  }
}
