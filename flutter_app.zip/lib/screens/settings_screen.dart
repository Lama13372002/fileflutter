import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/theme_service.dart';
import '../services/chat_service.dart';
import '../services/api_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({Key? key}) : super(key: key);

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  double _temperature = 0.7;
  int _maxTokens = 1024;
  bool _isSaving = false;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();

    setState(() {
      _temperature = prefs.getDouble('temperature') ?? 0.7;
      _maxTokens = prefs.getInt('max_tokens') ?? 1024;
    });
  }

  Future<void> _saveSettings() async {
    setState(() => _isSaving = true);

    try {
      final prefs = await SharedPreferences.getInstance();

      // Сохраняем настройки
      await prefs.setDouble('temperature', _temperature);
      await prefs.setInt('max_tokens', _maxTokens);

      // Показываем уведомление об успешном сохранении
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Настройки сохранены'),
            duration: Duration(seconds: 2),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Ошибка при сохранении настроек: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      setState(() => _isSaving = false);
    }
  }

  Future<void> _clearChat() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Очистить историю чата'),
        content: const Text(
          'Вы уверены, что хотите очистить всю историю чата? '
          'Это действие нельзя отменить.'
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Отмена'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('Очистить'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      final chatService = Provider.of<ChatService>(context, listen: false);
      chatService.clearCurrentChat();

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('История чата очищена'),
            duration: Duration(seconds: 2),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final themeService = Provider.of<ThemeService>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Настройки'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Секция API удалена, так как теперь API ключ устанавливается в коде

            // Секция настройки генерации
            _buildSectionTitle('Настройки генерации', theme),
            const SizedBox(height: 16),

            // Температура
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Температура: ${_temperature.toStringAsFixed(2)}',
                  style: theme.textTheme.bodyLarge,
                ),
                const SizedBox(height: 4),
                Text(
                  'Чем выше значение, тем более творческие и разнообразные ответы',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.onSurface.withOpacity(0.6),
                  ),
                ),
                Slider(
                  value: _temperature,
                  min: 0.0,
                  max: 1.0,
                  divisions: 20,
                  label: _temperature.toStringAsFixed(2),
                  onChanged: _isSaving
                      ? null
                      : (value) {
                          setState(() => _temperature = value);
                        },
                ),
              ],
            ),
            const SizedBox(height: 16),

            // Максимальное количество токенов
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Максимальное количество токенов: $_maxTokens',
                  style: theme.textTheme.bodyLarge,
                ),
                const SizedBox(height: 4),
                Text(
                  'Ограничивает длину генерируемого ответа',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.onSurface.withOpacity(0.6),
                  ),
                ),
                Slider(
                  value: _maxTokens.toDouble(),
                  min: 256,
                  max: 4096,
                  divisions: 15,
                  label: _maxTokens.toString(),
                  onChanged: _isSaving
                      ? null
                      : (value) {
                          setState(() => _maxTokens = value.toInt());
                        },
                ),
              ],
            ),
            const SizedBox(height: 24),

            // Секция темы
            _buildSectionTitle('Внешний вид', theme),
            const SizedBox(height: 16),

            // Переключатель темы
            Card(
              elevation: 0,
              color: theme.colorScheme.surfaceVariant,
              child: ListTile(
                title: const Text('Тёмная тема'),
                subtitle: const Text('Включить тёмное оформление'),
                leading: Icon(
                  themeService.isDarkMode
                      ? Icons.dark_mode
                      : Icons.light_mode,
                ),
                trailing: Switch(
                  value: themeService.isDarkMode,
                  onChanged: (value) {
                    themeService.setThemeMode(
                      value ? ThemeMode.dark : ThemeMode.light,
                    );
                  },
                ),
              ),
            ),
            const SizedBox(height: 24),

            // Секция управления данными
            _buildSectionTitle('Управление данными', theme),
            const SizedBox(height: 16),

            // Кнопка очистки истории чата
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: _isSaving ? null : _clearChat,
                icon: const Icon(Icons.delete_outline),
                label: const Text('Очистить историю чата'),
                style: ElevatedButton.styleFrom(
                  foregroundColor: theme.colorScheme.error,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
              ),
            ),
            const SizedBox(height: 32),

            // Кнопка сохранения
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: _isSaving ? null : _saveSettings,
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  child: _isSaving
                      ? const SizedBox(
                          width: 24,
                          height: 24,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : const Text('Сохранить настройки'),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title, ThemeData theme) {
    return Text(
      title,
      style: theme.textTheme.titleLarge?.copyWith(
        color: theme.colorScheme.primary,
        fontWeight: FontWeight.bold,
      ),
    ).animate().slideX(
      begin: -0.1,
      end: 0,
      duration: 300.ms,
      curve: Curves.easeOut,
    ).fadeIn(
      duration: 400.ms,
    );
  }
}
