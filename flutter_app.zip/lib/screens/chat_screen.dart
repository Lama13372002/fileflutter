import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../components/chat_input.dart';
import '../components/chat_message_bubble.dart';
import '../services/api_service.dart';
import '../services/chat_service.dart';
import '../services/theme_service.dart';
import '../models/message.dart';
import '../models/ai_model.dart';
import 'settings_screen.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({Key? key}) : super(key: key);

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> with SingleTickerProviderStateMixin {
  final ScrollController _scrollController = ScrollController();
  bool _isProcessing = false;
  String? _lastGeneratedMessageId;

  // Контроллер для управления боковой панелью
  late AnimationController _drawerController;
  late Animation<double> _drawerAnimation;

  // Состояние открытия боковой панели
  bool _isDrawerOpen = false;

  @override
  void initState() {
    super.initState();

    // Инициализируем контроллер анимации для боковой панели
    _drawerController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 250),
    );

    _drawerAnimation = CurvedAnimation(
      parent: _drawerController,
      curve: Curves.easeInOut,
    );

    // Добавляем приветственное сообщение после инициализации
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final chatService = Provider.of<ChatService>(context, listen: false);

      // Инициализируем сервис чата
      chatService.initialize();

      if (chatService.messages.isEmpty) {
        chatService.addAssistantMessage(
          content: 'Привет! Я многомодельный ИИ-ассистент. Чем могу помочь?',
        );
      }
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    _drawerController.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    if (_scrollController.hasClients) {
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  // Метод для переключения боковой панели
  void _toggleDrawer() {
    setState(() {
      _isDrawerOpen = !_isDrawerOpen;
      if (_isDrawerOpen) {
        _drawerController.forward();
      } else {
        _drawerController.reverse();
      }
    });
  }

  // Метод для создания нового чата
  void _createNewChat() {
    final chatService = Provider.of<ChatService>(context, listen: false);
    final apiService = Provider.of<ApiService>(context, listen: false);

    final newChat = chatService.createNewChat(aiModel: apiService.currentModel);

    // Добавляем приветственное сообщение
    chatService.addAssistantMessage(
      content: 'Привет! Я ${apiService.currentModel.name}. Чем могу помочь?',
    );

    // Закрываем боковую панель
    if (_isDrawerOpen) {
      _toggleDrawer();
    }
  }

  // Метод для изменения модели ИИ
  void _changeAIModel(AIModel model) {
    final apiService = Provider.of<ApiService>(context, listen: false);
    final chatService = Provider.of<ChatService>(context, listen: false);

    // Изменяем модель
    apiService.setModel(model);

    // Если есть текущий чат, меняем его модель
    if (chatService.currentChat != null) {
      chatService.changeChatModel(chatService.currentChat!.id, model);

      // Добавляем информационное сообщение
      chatService.addSystemMessage(
        content: 'Модель изменена на ${model.name}',
      );
    }

    // Показываем сообщение пользователю
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Выбрана модель ${model.name}'),
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  Future<void> _sendMessage(String text, {File? file}) async {
    if (text.isEmpty && file == null) return;

    final chatService = Provider.of<ChatService>(context, listen: false);
    final apiService = Provider.of<ApiService>(context, listen: false);

    // Добавляем сообщение пользователя
    chatService.addUserMessage(
      content: text,
      file: file,
    );

    // Прокручиваем чат вниз
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scrollToBottom();
    });

    setState(() => _isProcessing = true);

    try {
      // Проверка соединения с API перед отправкой запроса
      debugPrint('Проверка соединения с API...');
      final isConnected = await apiService.testConnection();
      if (!isConnected) {
        throw Exception('Не удалось подключиться к API. Проверьте ваше интернет-соединение или API ключ.');
      }

      // Создаем сообщение для отображения загрузки
      final loadingMessage = chatService.createLoadingMessage();
      chatService.addAssistantMessage(
        content: '',
        isLoading: true,
      );

      _lastGeneratedMessageId = loadingMessage.id;

      // Прокручиваем чат вниз
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _scrollToBottom();
      });

      // Если есть файл, отправляем его с сообщением
      if (file != null) {
        debugPrint('Отправка сообщения с файлом: ${file.path}');

        final fileBytes = await file.readAsBytes();
        final fileName = file.path.split('/').last;
        final mimeType = 'application/octet-stream'; // Можно определить точнее

        final response = await apiService.chatCompletionWithFile(
          prompt: text,
          fileData: fileBytes,
          fileName: fileName,
          mimeType: mimeType,
          history: chatService.getMessagesForApi(),
        );

        if (response.containsKey('choices') &&
            response['choices'].isNotEmpty &&
            response['choices'][0].containsKey('message') &&
            response['choices'][0]['message'].containsKey('content')) {

          final content = response['choices'][0]['message']['content'];
          chatService.updateLastMessage(
            content: content,
            isLoading: false,
          );
        } else {
          chatService.updateLastMessage(
            content: 'Извините, я не смог обработать ваш запрос.',
            isLoading: false,
          );
        }
      } else {
        // Используем потоковую передачу для текстовых сообщений
        debugPrint('Отправка текстового сообщения: $text');
        debugPrint('История сообщений: ${chatService.getMessagesForApi()}');

        final stream = apiService.streamChatCompletion(
          prompt: text,
          history: chatService.getMessagesForApi(),
        );

        String generatedText = '';
        bool hasReceivedAnyData = false;
        int updateCounter = 0;  // Счетчик для управления частотой обновлений UI
        Stopwatch streamTimer = Stopwatch()..start();

        try {
          await for (final chunk in stream) {
            hasReceivedAnyData = true;
            generatedText += chunk;
            updateCounter++;

            // Обновляем UI через определенные интервалы или размер данных,
            // чтобы не перегружать Flutter с частыми обновлениями состояния
            final elapsedMs = streamTimer.elapsedMilliseconds;
            if (updateCounter % 2 == 0 || chunk.length > 20 || elapsedMs > 300) {
              debugPrint('Обновление UI с новым текстом (${generatedText.length} символов), прошло ${elapsedMs}ms');

              // Сбрасываем таймер
              streamTimer.reset();
              streamTimer.start();

              // Обновляем сообщение
              chatService.updateLastMessage(
                content: generatedText,
                isLoading: true,
              );

              // Прокручиваем чат вниз при получении новых данных
              WidgetsBinding.instance.addPostFrameCallback((_) {
                _scrollToBottom();
              });

              // Небольшая пауза для визуализации потока
              await Future.delayed(const Duration(milliseconds: 10));
            }
          }

          // Проверяем, получили ли мы какие-либо данные
          if (!hasReceivedAnyData) {
            debugPrint('Ошибка: не получено данных от потока');
            throw Exception('Не получено данных от API');
          }

          debugPrint('Стриминг завершен, финальное обновление UI');

          // Обновляем последнее сообщение и снимаем статус загрузки
          chatService.updateLastMessage(
            content: generatedText,
            isLoading: false,
          );
        } catch (streamError) {
          debugPrint('Ошибка в потоке данных: $streamError');

          // Если мы уже получили какие-то данные, сохраняем их
          if (hasReceivedAnyData && generatedText.isNotEmpty) {
            chatService.updateLastMessage(
              content: '$generatedText\n\n[Соединение прервано]',
              isLoading: false,
            );
          } else {
            // Иначе показываем сообщение об ошибке
            chatService.updateLastMessage(
              content: 'Произошла ошибка при обработке запроса. Пожалуйста, попробуйте еще раз.',
              isLoading: false,
            );
          }

          // Повторно выбрасываем ошибку для внешней обработки
          throw streamError;
        }
      }
    } catch (e) {
      // Обработка ошибок
      debugPrint('Ошибка: $e');

      // Проверяем, было ли уже обновлено сообщение в блоке catch для потока
      final lastMessage = chatService.messages.isNotEmpty ? chatService.messages.last : null;
      if (lastMessage == null || lastMessage.isLoading) {
        chatService.updateLastMessage(
          content: 'Произошла ошибка при обработке запроса: $e\nПожалуйста, проверьте соединение с интернетом и попробуйте еще раз.',
          isLoading: false,
        );
      }
    } finally {
      setState(() => _isProcessing = false);

      // Прокручиваем чат вниз
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _scrollToBottom();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final chatService = Provider.of<ChatService>(context);
    final themeService = Provider.of<ThemeService>(context);
    final apiService = Provider.of<ApiService>(context);

    final currentModel = apiService.currentModel;

    return Scaffold(
      body: Stack(
        children: [
          // Основной контент
          Scaffold(
            appBar: AppBar(
              leading: IconButton(
                icon: const Icon(Icons.menu),
                onPressed: _toggleDrawer,
                tooltip: 'Чаты',
              ),
              title: Text('MULTI AI - ${currentModel.name}'),
              centerTitle: true,
              actions: [
                // Выпадающий список для выбора модели
                PopupMenuButton<AIModel>(
                  tooltip: 'Выбрать модель ИИ',
                  icon: Icon(
                    currentModel.icon,
                    color: currentModel.color,
                  ),
                  onSelected: _changeAIModel,
                  itemBuilder: (context) {
                    return AIModel.getAvailableModels().map((model) {
                      return PopupMenuItem<AIModel>(
                        value: model,
                        child: Row(
                          children: [
                            Icon(
                              model.icon,
                              color: model.color,
                              size: 20,
                            ),
                            const SizedBox(width: 8),
                            Text(model.name),
                          ],
                        ),
                      );
                    }).toList();
                  },
                ),
                IconButton(
                  icon: Icon(
                    themeService.isDarkMode
                        ? Icons.light_mode
                        : Icons.dark_mode,
                  ),
                  onPressed: () => themeService.toggleTheme(),
                  tooltip: 'Переключить тему',
                ),
                IconButton(
                  icon: const Icon(Icons.settings),
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (context) => const SettingsScreen(),
                      ),
                    );
                  },
                  tooltip: 'Настройки',
                ),
              ],
            ),
            body: Column(
              children: [
                // Список сообщений
                Expanded(
                  child: chatService.messages.isEmpty
                      ? _buildEmptyChat(theme)
                      : ListView.builder(
                          controller: _scrollController,
                          padding: const EdgeInsets.only(top: 16, bottom: 16),
                          itemCount: chatService.messages.length,
                          itemBuilder: (context, index) {
                            final message = chatService.messages[index];
                            final isLatestMessage = index == chatService.messages.length - 1;

                            return ChatMessageBubble(
                              message: message,
                              shouldAnimate: isLatestMessage && message.role == MessageRole.assistant,
                            );
                          },
                        ),
                ),

                // Поле ввода сообщения
                ChatInput(
                  onSendMessage: _sendMessage,
                  isLoading: _isProcessing,
                ),
              ],
            ),
            floatingActionButton: _buildFloatingActionButton(),
          ),

          // Боковая панель
          AnimatedBuilder(
            animation: _drawerAnimation,
            builder: (context, child) {
              return _buildDrawer(context);
            },
          ),
        ],
      ),
    );
  }

  // Метод для создания плавающей кнопки
  Widget? _buildFloatingActionButton() {
    final chatService = Provider.of<ChatService>(context);

    if (chatService.messages.isEmpty) return null;

    return FloatingActionButton(
      onPressed: _scrollToBottom,
      mini: true,
      child: const Icon(Icons.arrow_downward),
      tooltip: 'Прокрутить вниз',
    );
  }

  Widget _buildEmptyChat(ThemeData theme) {
    final apiService = Provider.of<ApiService>(context);

    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            apiService.currentModel.icon,
            size: 80,
            color: apiService.currentModel.color.withOpacity(0.5),
          ),
          const SizedBox(height: 16),
          Text(
            'Начните общение с ${apiService.currentModel.name}',
            style: TextStyle(
              fontSize: 18,
              color: theme.colorScheme.onSurface.withOpacity(0.7),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Задайте вопрос или отправьте изображение для анализа',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 14,
              color: theme.colorScheme.onSurface.withOpacity(0.5),
            ),
          ),
        ],
      ),
    ).animate().fade(
      duration: 600.ms,
      delay: 400.ms,
      curve: Curves.easeOut,
    );
  }

  // Метод для создания боковой панели
  Widget _buildDrawer(BuildContext context) {
    final chatService = Provider.of<ChatService>(context);
    final theme = Theme.of(context);

    return Positioned(
      left: 0,
      top: 0,
      bottom: 0,
      width: 300 * _drawerAnimation.value,
      child: Container(
        color: theme.colorScheme.surface,
        child: SafeArea(
          child: Column(
            children: [
              // Заголовок боковой панели
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: theme.colorScheme.primaryContainer.withOpacity(0.5),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Чаты',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: theme.colorScheme.onSurface,
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.add),
                      onPressed: _createNewChat,
                      tooltip: 'Новый чат',
                    ),
                  ],
                ),
              ),

              // Список чатов
              Expanded(
                child: chatService.chats.isEmpty
                    ? Center(
                        child: Text(
                          'Нет чатов',
                          style: TextStyle(
                            color: theme.colorScheme.onSurface.withOpacity(0.5),
                          ),
                        ),
                      )
                    : ListView.builder(
                        itemCount: chatService.chats.length,
                        itemBuilder: (context, index) {
                          final chat = chatService.chats[index];
                          final isSelected = chatService.currentChat?.id == chat.id;

                          return ListTile(
                            title: Text(
                              chat.title,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            subtitle: Text(
                              chat.preview,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontSize: 12,
                                color: theme.colorScheme.onSurface.withOpacity(0.6),
                              ),
                            ),
                            leading: Icon(
                              chat.aiModel.icon,
                              color: chat.aiModel.color,
                            ),
                            selected: isSelected,
                            selectedTileColor: theme.colorScheme.primaryContainer.withOpacity(0.3),
                            onTap: () {
                              // Выбираем чат
                              chatService.selectChat(chat.id);

                              // Закрываем боковую панель
                              if (_isDrawerOpen) {
                                _toggleDrawer();
                              }
                            },
                            trailing: IconButton(
                              icon: const Icon(Icons.delete_outline, size: 20),
                              onPressed: () {
                                // Показываем диалог подтверждения
                                showDialog(
                                  context: context,
                                  builder: (context) => AlertDialog(
                                    title: const Text('Удалить чат?'),
                                    content: const Text('Вы уверены, что хотите удалить этот чат? Это действие нельзя отменить.'),
                                    actions: [
                                      TextButton(
                                        onPressed: () => Navigator.of(context).pop(),
                                        child: const Text('Отмена'),
                                      ),
                                      TextButton(
                                        onPressed: () {
                                          chatService.deleteChat(chat.id);
                                          Navigator.of(context).pop();
                                        },
                                        child: const Text('Удалить'),
                                      ),
                                    ],
                                  ),
                                );
                              },
                              tooltip: 'Удалить чат',
                            ),
                          );
                        },
                      ),
              ),

              // Нижняя часть боковой панели
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: theme.colorScheme.surface,
                  border: Border(
                    top: BorderSide(
                      color: theme.colorScheme.outline.withOpacity(0.2),
                      width: 1,
                    ),
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        CircleAvatar(
                          backgroundColor: theme.colorScheme.primaryContainer,
                          radius: 16,
                          child: Text(
                            'A',
                            style: TextStyle(
                              color: theme.colorScheme.onPrimaryContainer,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        const Text('Пользователь'),
                      ],
                    ),
                    IconButton(
                      icon: const Icon(Icons.close),
                      onPressed: _toggleDrawer,
                      tooltip: 'Закрыть',
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
