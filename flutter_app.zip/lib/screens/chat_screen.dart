import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../components/chat_input.dart';
import '../components/chat_message_bubble.dart';
import '../services/api_service.dart';
import '../services/chat_service.dart';
import '../services/theme_service.dart';
import '../models/message.dart';
import '../models/ai_model.dart';
import 'settings_screen.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({Key? key}) : super(key: key);

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> with SingleTickerProviderStateMixin {
  final ScrollController _scrollController = ScrollController();
  bool _isProcessing = false;
  String? _lastGeneratedMessageId;
  bool _userScrolled = false; // Флаг для отслеживания пользовательской прокрутки

  // Контроллер для управления боковой панелью
  late AnimationController _drawerController;
  late Animation<double> _drawerAnimation;

  // Состояние открытия боковой панели
  bool _isDrawerOpen = false;
  bool _isChangingModel = false; // Флаг для отслеживания смены модели

  // Глобальный ключ для доступа к скаффолду для обработки жестов
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  // Переменная для отслеживания, был ли обнаружен жест на краю экрана
  bool _isEdgeSwipe = false;

  @override
  void initState() {
    super.initState();

    // Инициализируем контроллер анимации для боковой панели
    _drawerController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 250),
    );

    _drawerAnimation = CurvedAnimation(
      parent: _drawerController,
      curve: Curves.easeInOut,
    );

    // Добавляем слушатель для контроллера скролла, чтобы обновлять кнопку прокрутки вниз
    // и отслеживать пользовательскую прокрутку
    _scrollController.addListener(() {
      _updateScrollButtonVisibility();

      // Если пользователь прокрутил чат не до конца, отмечаем это
      if (_scrollController.hasClients &&
          _scrollController.position.pixels < _scrollController.position.maxScrollExtent - 50) {
        _userScrolled = true;
      } else if (_scrollController.hasClients &&
          _scrollController.position.pixels >= _scrollController.position.maxScrollExtent - 50) {
        // Если пользователь снова прокрутил вниз, сбрасываем флаг
        _userScrolled = false;
      }
    });

    // Добавляем приветственное сообщение после инициализации
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final chatService = Provider.of<ChatService>(context, listen: false);
      final apiService = Provider.of<ApiService>(context, listen: false);

      // Инициализируем сервис чата
      chatService.initialize();

      if (chatService.messages.isEmpty) {
        // Добавляем приветственное сообщение
        String welcomeMessage;

        switch (apiService.currentModel.type) {
          case AIModelType.qwen:
            welcomeMessage = 'Здравствуйте! Я ${apiService.currentModel.name}, продвинутая модель Qwen. Готов помочь с вашими запросами и задачами.';
            break;
          case AIModelType.gpt4mini:
            welcomeMessage = 'Привет! Я ${apiService.currentModel.name} - компактная версия GPT-4.1. Буду рад помочь с любыми вопросами!';
            break;
          case AIModelType.deepseekv3:
          case AIModelType.deepseekr1:
            welcomeMessage = 'Здравствуйте! Я ${apiService.currentModel.name}. Специализируюсь на глубоком анализе данных и сложных заданиях. Чем могу быть полезен?';
            break;
          case AIModelType.llama4maverick:
            welcomeMessage = 'Привет! Я ${apiService.currentModel.name}. Я эффективно справляюсь с различными текстовыми задачами и буду рад помочь вам.';
            break;
          case AIModelType.gemini:
          default:
            welcomeMessage = 'Привет! Я многомодельный ИИ-ассистент для повседневного общения и помощи. Задавайте любые вопросы, и я постараюсь помочь.';
            break;
        }

        chatService.addAssistantMessage(content: welcomeMessage);
      }

      // Инициализируем детектор жестов для открытия/закрытия меню
      _initGestureDetector();
    });
  }

  // Инициализация детектора жестов для открытия/закрытия меню жестом свайпа
  void _initGestureDetector() {
    // Получаем размеры экрана
    final width = MediaQuery.of(context).size.width;

    // Зона для распознавания жеста свайпа для открытия меню (левый край экрана)
    final edgeWidth = width * 0.15; // 15% ширины экрана

    // Для Flutter, GestureDetector должен быть в дереве виджетов, поэтому
    // мы реализуем обработку свайпов непосредственно в build через GestureDetector.
  }

  // Метод для обновления видимости кнопки скроллинга
  void _updateScrollButtonVisibility() {
    // Принудительно обновляем интерфейс, чтобы кнопка появлялась/исчезала
    setState(() {});
  }

  @override
  void dispose() {
    // Удаляем слушатель при уничтожении виджета
    _scrollController.dispose();
    _drawerController.dispose();
    super.dispose();
  }

  /// Прокручивает чат к низу, если пользователь не прокручивал вверх вручную,
  /// либо если force=true (принудительно).
  void _scrollToBottom({bool force = false}) {
    if (_scrollController.hasClients) {
      // Если пользователь прокрутил чат вверх и не требуется принудительная прокрутка, не прокручиваем
      if (_userScrolled && !force) {
        return;
      }

      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  // Метод для переключения боковой панели
  void _toggleDrawer() {
    setState(() {
      _isDrawerOpen = !_isDrawerOpen;
      if (_isDrawerOpen) {
        _drawerController.forward();
      } else {
        _drawerController.reverse();
      }
    });
  }

  /// Создаёт новый чат с текущей моделью и приветственным сообщением.
  void _createNewChat() {
    final chatService = Provider.of<ChatService>(context, listen: false);
    final apiService = Provider.of<ApiService>(context, listen: false);

    final newChat = chatService.createNewChat(aiModel: apiService.currentModel);

    String welcomeMessage;

    switch (apiService.currentModel.type) {
      case AIModelType.qwen:
        welcomeMessage = 'Здравствуйте! Я ${apiService.currentModel.name}, продвинутая модель Qwen. Готов помочь с вашими запросами и задачами.';
        break;
      case AIModelType.gpt4mini:
        welcomeMessage = 'Привет! Я ${apiService.currentModel.name} - компактная версия GPT-4.1. Буду рад помочь с любыми вопросами!';
        break;
      case AIModelType.deepseekv3:
      case AIModelType.deepseekr1:
        welcomeMessage = 'Здравствуйте! Я ${apiService.currentModel.name}. Специализируюсь на глубоком анализе данных и сложных заданиях. Чем могу быть полезен?';
        break;
      case AIModelType.llama4maverick:
        welcomeMessage = 'Привет! Я ${apiService.currentModel.name}. Я эффективно справляюсь с различными текстовыми задачами и буду рад помочь вам.';
        break;
      case AIModelType.gemini:
      default:
        welcomeMessage = 'Привет! Я ${apiService.currentModel.name}. Чем могу помочь?';
        break;
    }

    chatService.addAssistantMessage(content: welcomeMessage);

    if (_isDrawerOpen) {
      _toggleDrawer();
    }
  }

  /// Смена модели ИИ с созданием нового чата и приветственным сообщением.
  Future<void> _changeAIModel(AIModel model) async {
    final apiService = Provider.of<ApiService>(context, listen: false);
    final chatService = Provider.of<ChatService>(context, listen: false);

    if (apiService.currentModel.id == model.id) {
      return;
    }

    setState(() {
      _isChangingModel = true;
    });

    await Future.delayed(const Duration(milliseconds: 300));

    apiService.setModel(model);

    final newChat = chatService.createNewChat(aiModel: model);

    String welcomeMessage;

    switch (model.type) {
      case AIModelType.qwen:
        welcomeMessage = 'Здравствуйте! Я ${model.name}, продвинутая модель Qwen. Готов помочь с вашими запросами и задачами.';
        break;
      case AIModelType.gpt4mini:
        welcomeMessage = 'Привет! Я ${model.name} - компактная версия GPT-4.1. Буду рад помочь с любыми вопросами!';
        break;
      case AIModelType.deepseekv3:
      case AIModelType.deepseekr1:
        welcomeMessage = 'Здравствуйте! Я ${model.name}. Специализируюсь на глубоком анализе данных и сложных заданиях. Чем могу быть полезен?';
        break;
      case AIModelType.llama4maverick:
        welcomeMessage = 'Привет! Я ${model.name}. Я эффективно справляюсь с различными текстовыми задачами и буду рад помочь вам.';
        break;
      case AIModelType.gemini:
      default:
        welcomeMessage = 'Привет! Я ${model.name}. Чем могу помочь?';
        break;
    }

    chatService.addAssistantMessage(content: welcomeMessage);

    setState(() {
      _isChangingModel = false;
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      Future.delayed(const Duration(milliseconds: 100), () => _scrollToBottom(force: true));
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            model.logoAsset != null
                ? ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: Image.asset(
                      model.logoAsset!,
                      width: 20,
                      height: 20,
                      fit: BoxFit.contain,
                    ),
                  )
                : Icon(model.icon, color: model.color, size: 20),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Создан новый чат с ${model.name}',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  Text(
                    'Предыдущий чат сохранен в истории',
                    style: TextStyle(
                      fontSize: 12,
                      color: Theme.of(context).snackBarTheme.contentTextStyle?.color?.withOpacity(0.7)
                          ?? Colors.white70,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 3),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        action: SnackBarAction(
          label: 'OK',
          onPressed: () {},
        ),
      ),
    );
  }

  /// Отправляет сообщение пользователя (и файл, если есть) в чат и обрабатывает ответ ИИ.
  Future<void> _sendMessage(String text, {File? file}) async {
    if (text.isEmpty && file == null) return;

    final chatService = Provider.of<ChatService>(context, listen: false);
    final apiService = Provider.of<ApiService>(context, listen: false);

    // Проверяем, поддерживает ли текущая модель работу с файлами
    if (file != null) {
      final isImage = _isFileImage(file);
      final currentModel = apiService.currentModel;

      if ((isImage && !currentModel.supportsImageAnalysis) ||
          (!isImage && !currentModel.supportsFileAnalysis)) {

        // Создаем список поддерживаемых моделей
        final supportedModels = isImage
            ? AIModel.getModelsWithImageAnalysis()
            : AIModel.getModelsWithFileAnalysis();

        final supportedModelsText = supportedModels
            .map((m) => m.name)
            .join(', ');

        // Показываем диалог с предупреждением
        await showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: Text('Модель не поддерживает ${isImage ? 'изображения' : 'файлы'}'),
            content: Text(
              'Текущая модель (${currentModel.name}) не поддерживает анализ ${isImage ? 'изображений' : 'файлов'}. '
              'Поддерживаемые модели: $supportedModelsText\n\n'
              'Хотите продолжить только с текстовым сообщением?'
            ),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop(false);
                },
                child: Text('Отмена'),
              ),
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop(true);
                },
                child: Text('Продолжить без файла'),
              ),
            ],
          ),
        ).then((continueWithoutFile) {
          if (continueWithoutFile == true) {
            // Продолжаем только с текстовым сообщением
            _sendMessageInternal(text, null);
          }
        });

        return; // Прерываем выполнение метода
      }
    }

    // Если проверка прошла успешно, отправляем сообщение
    _sendMessageInternal(text, file);
  }

  // Вспомогательный метод для определения, является ли файл изображением
  bool _isFileImage(File file) {
    final extension = file.path.split('.').last.toLowerCase();
    return ['jpg', 'jpeg', 'png', 'gif'].contains(extension);
  }

  // Внутренний метод для отправки сообщения
  Future<void> _sendMessageInternal(String text, File? file) async {
    _userScrolled = false;

    final chatService = Provider.of<ChatService>(context, listen: false);
    final apiService = Provider.of<ApiService>(context, listen: false);

    chatService.addUserMessage(
      content: text,
      file: file,
    );

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scrollToBottom(force: true);
    });

    setState(() => _isProcessing = true);

    try {
      debugPrint('Проверка соединения с API...');
      final isConnected = await apiService.testConnection();
      if (!isConnected) {
        throw Exception('Не удалось подключиться к API. Проверьте ваше интернет-соединение или API ключ.');
      }

      final loadingMessage = chatService.createLoadingMessage();
      chatService.addAssistantMessage(
        content: '',
        isLoading: true,
      );

      _lastGeneratedMessageId = loadingMessage.id;

      WidgetsBinding.instance.addPostFrameCallback((_) {
        _scrollToBottom(force: true);
      });

      if (file != null) {
        debugPrint('Отправка сообщения с файлом: ${file.path}');

        final fileBytes = await file.readAsBytes();
        final fileName = file.path.split('/').last;

        // Определяем MIME-тип файла на основе расширения
        final fileExtension = fileName.split('.').last.toLowerCase();
        String mimeType;

        switch (fileExtension) {
          case 'jpg':
          case 'jpeg':
            mimeType = 'image/jpeg';
            break;
          case 'png':
            mimeType = 'image/png';
            break;
          case 'gif':
            mimeType = 'image/gif';
            break;
          case 'pdf':
            mimeType = 'application/pdf';
            break;
          case 'mp3':
            mimeType = 'audio/mpeg';
            break;
          case 'mp4':
            mimeType = 'video/mp4';
            break;
          case 'docx':
            mimeType = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
            break;
          case 'xlsx':
            mimeType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
            break;
          default:
            mimeType = 'application/octet-stream';
        }

        debugPrint('Определён MIME-тип файла: $mimeType');

        final response = await apiService.chatCompletionWithFile(
          prompt: text,
          fileData: fileBytes,
          fileName: fileName,
          mimeType: mimeType,
          history: chatService.getMessagesForApi(),
        );

        if (response.containsKey('choices') &&
            response['choices'].isNotEmpty &&
            response['choices'][0].containsKey('message') &&
            response['choices'][0]['message'].containsKey('content')) {

          final content = response['choices'][0]['message']['content'];
          chatService.updateLastMessage(
            content: content,
            isLoading: false,
          );
        } else {
          chatService.updateLastMessage(
            content: 'Извините, я не смог обработать ваш запрос.',
            isLoading: false,
          );
        }
      } else {
        debugPrint('Отправка текстового сообщения: $text');
        debugPrint('История сообщений: ${chatService.getMessagesForApi()}');

        final stream = apiService.streamChatCompletion(
          prompt: text,
          history: chatService.getMessagesForApi(),
        );

        String generatedText = '';
        bool hasReceivedAnyData = false;
        int updateCounter = 0;
        Stopwatch streamTimer = Stopwatch()..start();

        bool firstResponse = true;

        try {
          await for (final chunk in stream) {
            hasReceivedAnyData = true;
            generatedText += chunk;
            updateCounter++;

            final elapsedMs = streamTimer.elapsedMilliseconds;
            if (updateCounter % 2 == 0 || chunk.length > 20 || elapsedMs > 300) {
              debugPrint('Обновление UI с новым текстом (${generatedText.length} символов), прошло ${elapsedMs}ms');

              streamTimer.reset();
              streamTimer.start();

              chatService.updateLastMessage(
                content: generatedText,
                isLoading: true,
              );

              if (firstResponse) {
                WidgetsBinding.instance.addPostFrameCallback((_) {
                  _scrollToBottom(force: true);
                });
                firstResponse = false;
              }

              await Future.delayed(const Duration(milliseconds: 10));
            }
          }

          if (!hasReceivedAnyData) {
            debugPrint('Ошибка: не получено данных от потока');
            throw Exception('Не получено данных от API');
          }

          debugPrint('Стриминг завершен, финальное обновление UI');

          chatService.updateLastMessage(
            content: generatedText,
            isLoading: false,
          );
        } catch (streamError) {
          debugPrint('Ошибка в потоке данных: $streamError');

          if (hasReceivedAnyData && generatedText.isNotEmpty) {
            chatService.updateLastMessage(
              content: '$generatedText\n\n[Соединение прервано]',
              isLoading: false,
            );
          } else {
            chatService.updateLastMessage(
              content: 'Произошла ошибка при обработке запроса. Пожалуйста, попробуйте еще раз.',
              isLoading: false,
            );
          }

          throw streamError;
        }
      }
    } catch (e) {
      debugPrint('Ошибка: $e');

      final lastMessage = chatService.messages.isNotEmpty ? chatService.messages.last : null;
      if (lastMessage == null || lastMessage.isLoading) {
        chatService.updateLastMessage(
          content: 'Произошла ошибка при обработке запроса: $e\nПожалуйста, проверьте соединение с интернетом и попробуйте еще раз.',
          isLoading: false,
        );
      }
    } finally {
      setState(() => _isProcessing = false);

      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!_userScrolled) {
          _scrollToBottom();
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final chatService = Provider.of<ChatService>(context);
    final themeService = Provider.of<ThemeService>(context);
    final apiService = Provider.of<ApiService>(context);

    final currentModel = apiService.currentModel;

    final width = MediaQuery.of(context).size.width;
    final edgeWidth = width * 0.15;

    return GestureDetector(
      onHorizontalDragStart: (details) {
        if (!_isDrawerOpen && details.globalPosition.dx < edgeWidth) {
          setState(() {
            _isEdgeSwipe = true;
          });
        }
      },
      onHorizontalDragUpdate: (details) {
        if (!_isEdgeSwipe && !_isDrawerOpen) return;

        if (_isDrawerOpen) {
          final dragValue = (details.globalPosition.dx / (width * 0.7)).clamp(0.0, 1.0);
          _drawerController.value = dragValue;
        } else if (_isEdgeSwipe) {
          final dragValue = (details.globalPosition.dx / (width * 0.7)).clamp(0.0, 1.0);
          _drawerController.value = dragValue;
        }
      },
      onHorizontalDragEnd: (details) {
        if (_drawerController.value < 0.5) {
          _drawerController.reverse();
          setState(() {
            _isDrawerOpen = false;
            _isEdgeSwipe = false;
          });
        } else {
          _drawerController.forward();
          setState(() {
            _isDrawerOpen = true;
            _isEdgeSwipe = false;
          });
        }
      },
      behavior: HitTestBehavior.translucent,
      child: Scaffold(
        key: _scaffoldKey,
        appBar: AppBar(
          leading: IconButton(
            icon: Icon(
              Icons.menu,
              color: Theme.of(context).colorScheme.onBackground,
            ),
            onPressed: _toggleDrawer,
            tooltip: 'Чаты',
          ),
          title: Text(
            'MULTI AI - ${currentModel.name}',
            style: TextStyle(
              color: Theme.of(context).colorScheme.onBackground,
              fontWeight: FontWeight.bold,
            ),
          ),
          centerTitle: true,
          actions: [
            _buildModelSelector(currentModel, apiService),
            IconButton(
              icon: Icon(
                themeService.isDarkMode
                    ? Icons.light_mode
                    : Icons.dark_mode,
                color: Theme.of(context).colorScheme.onBackground,
              ),
              onPressed: () => themeService.toggleTheme(),
              tooltip: 'Переключить тему',
            ),
            IconButton(
              icon: Icon(
                Icons.settings,
                color: Theme.of(context).colorScheme.onBackground,
              ),
              onPressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (context) => const SettingsScreen(),
                  ),
                );
              },
              tooltip: 'Настройки',
            ),
          ],
        ),
        body: Stack(
          children: [
            Column(
              children: [
                Expanded(
                  child: chatService.messages.isEmpty
                      ? _buildEmptyChat(theme)
                      : ListView.builder(
                          controller: _scrollController,
                          padding: const EdgeInsets.only(top: 16, bottom: 16),
                          itemCount: chatService.messages.length,
                          itemBuilder: (context, index) {
                            final message = chatService.messages[index];
                            final isLatestMessage = index == chatService.messages.length - 1;

                            return ChatMessageBubble(
                              message: message,
                              shouldAnimate: isLatestMessage && message.role == MessageRole.assistant,
                            );
                          },
                        ),
                ),
                ChatInput(
                  onSendMessage: _sendMessage,
                  isLoading: _isProcessing || _isChangingModel,
                ),
              ],
            ),
            // Анимация боковой панели (drawer)
            AnimatedBuilder(
              animation: _drawerAnimation,
              builder: (context, child) {
                return _buildDrawer(context);
              },
            ),
            _buildFloatingActionButton() ?? const SizedBox.shrink(),
            if (_isChangingModel)
              Positioned.fill(
                child: Container(
                  color: Colors.black.withOpacity(0.15),
                  child: Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const CircularProgressIndicator(),
                        const SizedBox(height: 16),
                        Text(
                          'Смена модели...',
                          style: TextStyle(
                            color: theme.colorScheme.onSurface,
                            fontSize: 16,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  /// Строит выпадающий список выбора модели ИИ.
  Widget _buildModelSelector(AIModel currentModel, ApiService apiService) {
    return PopupMenuButton<AIModel>(
      tooltip: 'Выбрать модель ИИ',
      position: PopupMenuPosition.under,
      offset: const Offset(0, 10),
      icon: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            currentModel.logoAsset != null
                ? ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: Image.asset(
                      currentModel.logoAsset!,
                      width: 24,
                      height: 24,
                    ),
                  )
                : Icon(
                    currentModel.icon,
                    color: currentModel.color.withOpacity(Theme.of(context).brightness == Brightness.dark ? 1.0 : 0.9),
                    size: 20,
                  ),
          ],
        ),
      ),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      color: Theme.of(context).colorScheme.surface,
      elevation: 3,
      onSelected: (model) => _changeAIModel(model),
      itemBuilder: (context) {
        final theme = Theme.of(context);
        final list = AIModel.getAvailableModels();

        return list.map((model) {
          final isSelected = model.id == currentModel.id;

          return PopupMenuItem<AIModel>(
            value: model,
            padding: EdgeInsets.zero,
            child: Container(
              decoration: BoxDecoration(
                color: isSelected ? theme.colorScheme.primaryContainer.withOpacity(0.3) : Colors.transparent,
                borderRadius: BorderRadius.circular(12),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: theme.brightness == Brightness.dark
                          ? model.color.withOpacity(0.3) // Увеличиваем непрозрачность для темной темы
                          : model.color.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Center(
                      child: model.logoAsset != null
                          ? ClipRRect(
                              borderRadius: BorderRadius.circular(8),
                              child: Image.asset(
                                model.logoAsset!,
                                width: 32,
                                height: 32,
                                fit: BoxFit.contain,
                              ),
                            )
                          : Icon(
                              model.icon,
                              color: model.color,
                              size: 20,
                            ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          model.name,
                          style: TextStyle(
                            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                            fontSize: 14,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          model.description,
                          style: TextStyle(
                            fontSize: 12,
                            color: theme.colorScheme.onSurface.withOpacity(0.6),
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (isSelected)
                    Container(
                      width: 20,
                      height: 20,
                      decoration: BoxDecoration(
                        color: model.color.withOpacity(Theme.of(context).brightness == Brightness.dark ? 1.0 : 0.9),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.check,
                        color: Colors.white,
                        size: 14,
                      ),
                    ),
                ],
              ),
            ),
          );
        }).toList();
      },
    );
  }

  /// Строит плавающую кнопку для прокрутки вниз, если чат прокручен вверх.
  Widget? _buildFloatingActionButton() {
    final chatService = Provider.of<ChatService>(context);

    if (chatService.messages.isEmpty) return null;

    bool shouldShowButton = false;

    if (_scrollController.hasClients) {
      shouldShowButton = _scrollController.position.maxScrollExtent > 0 &&
                         _scrollController.position.pixels < _scrollController.position.maxScrollExtent - 100;
    }

    if (!shouldShowButton) return null;

    return Positioned(
      right: 16,
      bottom: 80,
      child: FloatingActionButton(
        onPressed: () {
          _userScrolled = false;
          _scrollToBottom(force: true);
        },
        mini: true,
        backgroundColor: Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.8),
        elevation: 2,
        child: Icon(
          Icons.arrow_downward,
          size: 18,
          color: Theme.of(context).colorScheme.onSurfaceVariant,
        ),
        tooltip: 'Прокрутить вниз',
      ),
    );
  }

  /// Строит экран приветствия, если сообщений в чате нет.
  Widget _buildEmptyChat(ThemeData theme) {
    final apiService = Provider.of<ApiService>(context);

    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          apiService.currentModel.logoAsset != null
              ? ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: Image.asset(
                    apiService.currentModel.logoAsset!,
                    width: 80,
                    height: 80,
                    fit: BoxFit.contain,
                  ),
                )
              : Icon(
                  apiService.currentModel.icon,
                  size: 80,
                  color: apiService.currentModel.color.withOpacity(Theme.of(context).brightness == Brightness.dark ? 0.7 : 0.5),
                ),
          const SizedBox(height: 16),
          Text(
            'Начните общение с ${apiService.currentModel.name}',
            style: TextStyle(
              fontSize: 18,
              color: theme.colorScheme.onSurface.withOpacity(0.7),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Задайте вопрос или отправьте изображение для анализа',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 14,
              color: theme.colorScheme.onSurface.withOpacity(0.5),
            ),
          ),
        ],
      ),
    ).animate().fade(
      duration: 600.ms,
      delay: 400.ms,
      curve: Curves.easeOut,
    );
  }

  /// Строит анимированную боковую панель (drawer) с историей чатов.
  ///
  /// Анимация боковой панели реализована следующим образом:
  /// - Ширина панели плавно изменяется от 0 до 300 пикселей в зависимости от значения анимации [_drawerAnimation.value].
  /// - Содержимое панели появляется с задержкой: opacity содержимого становится >0 только при [_drawerAnimation.value] > 0.7,
  ///   что создаёт эффект "выезда" панели, а затем плавного появления содержимого.
  /// - Тень и скругления панели также анимируются.
  /// - Панель реагирует на свайпы и может быть открыта/закрыта как по кнопке, так и жестом.
  Widget _buildDrawer(BuildContext context) {
    final chatService = Provider.of<ChatService>(context);
    final theme = Theme.of(context);

    if (_drawerAnimation.value == 0) {
      return const SizedBox.shrink();
    }

    // Анимация исчезновения содержимого боковой панели при её закрытии:
    // содержимое становится видимым только при значении анимации > 0.7
    final contentOpacity = _drawerAnimation.value < 0.7
        ? 0.0
        : (_drawerAnimation.value - 0.7) / 0.3;

    return Positioned(
      left: 0,
      top: 0,
      bottom: 0,
      width: 300 * _drawerAnimation.value,
      child: Container(
        decoration: BoxDecoration(
          color: theme.colorScheme.surface,
          borderRadius: const BorderRadius.only(
            topRight: Radius.circular(24),
            bottomRight: Radius.circular(24),
          ),
          boxShadow: [
            BoxShadow(
              color: theme.colorScheme.shadow.withOpacity(0.1 * _drawerAnimation.value),
              blurRadius: 10 * _drawerAnimation.value,
              spreadRadius: 2 * _drawerAnimation.value,
              offset: Offset(2 * _drawerAnimation.value, 0),
            ),
          ],
        ),
        child: ClipRect(
          child: SafeArea(
            child: AnimatedOpacity(
              duration: const Duration(milliseconds: 150),
              opacity: contentOpacity,
              child: Column(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                    decoration: BoxDecoration(
                      color: theme.colorScheme.primaryContainer.withOpacity(0.5),
                      borderRadius: const BorderRadius.only(
                        topRight: Radius.circular(24),
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Ваши чаты',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: theme.colorScheme.onSurface,
                          ),
                        ),
                        ElevatedButton.icon(
                          onPressed: _createNewChat,
                          icon: const Icon(Icons.add, size: 16),
                          label: const Text('Новый'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: theme.colorScheme.primaryContainer,
                            foregroundColor: theme.colorScheme.onPrimaryContainer,
                            elevation: 0,
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: chatService.chats.isEmpty
                        ? Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.chat_bubble_outline,
                                  size: 48,
                                  color: theme.colorScheme.onSurface.withOpacity(0.3),
                                ),
                                const SizedBox(height: 16),
                                Text(
                                  'Нет чатов',
                                  style: TextStyle(
                                    color: theme.colorScheme.onSurface.withOpacity(0.5),
                                    fontSize: 16,
                                  ),
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  'Создайте новый чат, чтобы начать общение',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: theme.colorScheme.onSurface.withOpacity(0.3),
                                    fontSize: 14,
                                  ),
                                ),
                              ],
                            ),
                          )
                        : ListView.builder(
                            itemCount: chatService.chats.length,
                            padding: const EdgeInsets.symmetric(vertical: 8),
                            itemBuilder: (context, index) {
                              final chat = chatService.chats[index];
                              final isSelected = chatService.currentChat?.id == chat.id;

                              return Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: isSelected
                                      ? theme.colorScheme.primaryContainer.withOpacity(0.3)
                                      : theme.colorScheme.surface,
                                    borderRadius: BorderRadius.circular(16),
                                    border: Border.all(
                                      color: isSelected
                                        ? theme.colorScheme.primary.withOpacity(0.3)
                                        : theme.colorScheme.outline.withOpacity(0.1),
                                      width: 1,
                                    ),
                                  ),
                                  child: InkWell(
                                    onTap: () {
                                      chatService.selectChat(chat.id);

                                      if (_isDrawerOpen) {
                                        _toggleDrawer();
                                      }
                                    },
                                    borderRadius: BorderRadius.circular(16),
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                                      child: Row(
                                        children: [
                                          Container(
                                            width: 40,
                                            height: 40,
                                            decoration: BoxDecoration(
                                              color: theme.brightness == Brightness.dark
                                                  ? chat.aiModel.color.withOpacity(0.3) // Увеличиваем непрозрачность для темной темы
                                                  : chat.aiModel.color.withOpacity(0.1),
                                              borderRadius: BorderRadius.circular(12),
                                            ),
                                            child: Center(
                                              child: chat.aiModel.logoAsset != null
                                                  ? ClipRRect(
                                                      borderRadius: BorderRadius.circular(8),
                                                      child: Image.asset(
                                                        chat.aiModel.logoAsset!,
                                                        width: 32,
                                                        height: 32,
                                                        fit: BoxFit.contain,
                                                      ),
                                                    )
                                                  : Icon(
                                                      chat.aiModel.icon,
                                                      color: chat.aiModel.color,
                                                      size: 20,
                                                    ),
                                            ),
                                          ),
                                          const SizedBox(width: 12),
                                          Expanded(
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  chat.title,
                                                  maxLines: 1,
                                                  overflow: TextOverflow.ellipsis,
                                                  style: TextStyle(
                                                    fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                                                    fontSize: 14,
                                                  ),
                                                ),
                                                const SizedBox(height: 4),
                                                Text(
                                                  chat.preview,
                                                  maxLines: 1,
                                                  overflow: TextOverflow.ellipsis,
                                                  style: TextStyle(
                                                    fontSize: 12,
                                                    color: theme.colorScheme.onSurface.withOpacity(0.6),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          IconButton(
                                            icon: Icon(
                                              Icons.delete_outline,
                                              size: 18,
                                              color: theme.colorScheme.error.withOpacity(0.7),
                                            ),
                                            onPressed: () {
                                              showDialog(
                                                context: context,
                                                builder: (context) => AlertDialog(
                                                  title: const Text('Удалить чат?'),
                                                  content: const Text('Вы уверены, что хотите удалить этот чат? Это действие нельзя отменить.'),
                                                  shape: RoundedRectangleBorder(
                                                    borderRadius: BorderRadius.circular(16),
                                                  ),
                                                  actions: [
                                                    TextButton(
                                                      onPressed: () => Navigator.of(context).pop(),
                                                      child: const Text('Отмена'),
                                                    ),
                                                    FilledButton(
                                                      onPressed: () {
                                                        chatService.deleteChat(chat.id);
                                                        Navigator.of(context).pop();
                                                      },
                                                      style: FilledButton.styleFrom(
                                                        backgroundColor: theme.colorScheme.error,
                                                        shape: RoundedRectangleBorder(
                                                          borderRadius: BorderRadius.circular(8),
                                                        ),
                                                      ),
                                                      child: const Text('Удалить'),
                                                    ),
                                                  ],
                                                ),
                                              );
                                            },
                                            tooltip: 'Удалить чат',
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                    decoration: BoxDecoration(
                      color: theme.colorScheme.surfaceVariant.withOpacity(0.5),
                      borderRadius: const BorderRadius.only(
                        bottomRight: Radius.circular(24),
                      ),
                    ),
                    child: Row(
                      children: [
                        CircleAvatar(
                          backgroundColor: theme.colorScheme.primaryContainer,
                          radius: 18,
                          child: Text(
                            'A',
                            style: TextStyle(
                              color: theme.colorScheme.onPrimaryContainer,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        const Expanded(
                          child: Text(
                            'Пользователь',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: theme.colorScheme.surface,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                              color: theme.colorScheme.outline.withOpacity(0.2),
                              width: 1,
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.swipe_left_alt,
                                size: 16,
                                color: theme.colorScheme.primary,
                              ),
                              const SizedBox(width: 4),
                              const Text(
                                'Закрыть',
                                style: TextStyle(
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
