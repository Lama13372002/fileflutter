import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../components/chat_input.dart';
import '../components/chat_message_bubble.dart';
import '../services/api_service.dart';
import '../services/chat_service.dart';
import '../services/theme_service.dart';
import '../models/message.dart';
import 'settings_screen.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({Key? key}) : super(key: key);

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final ScrollController _scrollController = ScrollController();
  bool _isProcessing = false;
  String? _lastGeneratedMessageId;

  @override
  void initState() {
    super.initState();

    // Добавляем приветственное сообщение после инициализации
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final chatService = Provider.of<ChatService>(context, listen: false);
      chatService.addAssistantMessage(
        content: 'Привет! Я Gemini AI, ваш интеллектуальный ассистент. Чем могу помочь?',
      );
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    if (_scrollController.hasClients) {
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  Future<void> _sendMessage(String text, {File? file}) async {
    if (text.isEmpty && file == null) return;

    final chatService = Provider.of<ChatService>(context, listen: false);
    final apiService = Provider.of<ApiService>(context, listen: false);

    // Добавляем сообщение пользователя
    chatService.addUserMessage(
      content: text,
      file: file,
    );

    // Прокручиваем чат вниз
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scrollToBottom();
    });

    setState(() => _isProcessing = true);

    try {
      // Создаем сообщение для отображения загрузки
      final loadingMessage = chatService.createLoadingMessage();
      chatService.addAssistantMessage(
        content: '',
        isLoading: true,
      );

      _lastGeneratedMessageId = loadingMessage.id;

      // Прокручиваем чат вниз
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _scrollToBottom();
      });

      // Если есть файл, отправляем его с сообщением
      if (file != null) {
        final fileBytes = await file.readAsBytes();
        final fileName = file.path.split('/').last;
        final mimeType = 'application/octet-stream'; // Можно определить точнее

        final response = await apiService.chatCompletionWithFile(
          prompt: text,
          fileData: fileBytes,
          fileName: fileName,
          mimeType: mimeType,
          history: chatService.getMessagesForApi(),
        );

        if (response.containsKey('choices') &&
            response['choices'].isNotEmpty &&
            response['choices'][0].containsKey('message') &&
            response['choices'][0]['message'].containsKey('content')) {

          final content = response['choices'][0]['message']['content'];
          chatService.updateLastMessage(
            content: content,
            isLoading: false,
          );
        } else {
          chatService.updateLastMessage(
            content: 'Извините, я не смог обработать ваш запрос.',
            isLoading: false,
          );
        }
      } else {
        // Используем потоковую передачу для текстовых сообщений
        final stream = apiService.streamChatCompletion(
          prompt: text,
          history: chatService.getMessagesForApi(),
        );

        String generatedText = '';

        await for (final chunk in stream) {
          generatedText += chunk;
          chatService.updateLastMessage(
            content: generatedText,
            isLoading: true,
          );

          // Прокручиваем чат вниз при получении новых данных
          WidgetsBinding.instance.addPostFrameCallback((_) {
            _scrollToBottom();
          });
        }

        // Обновляем последнее сообщение и снимаем статус загрузки
        chatService.updateLastMessage(
          content: generatedText,
          isLoading: false,
        );
      }
    } catch (e) {
      // Обработка ошибок
      chatService.updateLastMessage(
        content: 'Произошла ошибка при обработке запроса. Пожалуйста, попробуйте еще раз.',
        isLoading: false,
      );

      debugPrint('Error: $e');
    } finally {
      setState(() => _isProcessing = false);

      // Прокручиваем чат вниз
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _scrollToBottom();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final chatService = Provider.of<ChatService>(context);
    final themeService = Provider.of<ThemeService>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Gemini AI Ассистент'),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(
              themeService.isDarkMode
                  ? Icons.light_mode
                  : Icons.dark_mode,
            ),
            onPressed: () => themeService.toggleTheme(),
            tooltip: 'Переключить тему',
          ),
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (context) => const SettingsScreen(),
                ),
              );
            },
            tooltip: 'Настройки',
          ),
        ],
      ),
      body: Column(
        children: [
          // Список сообщений
          Expanded(
            child: chatService.messages.isEmpty
                ? _buildEmptyChat(theme)
                : ListView.builder(
                    controller: _scrollController,
                    padding: const EdgeInsets.only(top: 16, bottom: 16),
                    itemCount: chatService.messages.length,
                    itemBuilder: (context, index) {
                      final message = chatService.messages[index];
                      final isLatestMessage = index == chatService.messages.length - 1;

                      return ChatMessageBubble(
                        message: message,
                        shouldAnimate: isLatestMessage && message.role == MessageRole.assistant,
                      );
                    },
                  ),
          ),

          // Поле ввода сообщения
          ChatInput(
            onSendMessage: _sendMessage,
            isLoading: _isProcessing,
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyChat(ThemeData theme) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.chat_bubble_outline,
            size: 80,
            color: theme.colorScheme.primary.withOpacity(0.5),
          ),
          const SizedBox(height: 16),
          Text(
            'Начните общение с Gemini AI',
            style: TextStyle(
              fontSize: 18,
              color: theme.colorScheme.onSurface.withOpacity(0.7),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Задайте вопрос или отправьте изображение для анализа',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 14,
              color: theme.colorScheme.onSurface.withOpacity(0.5),
            ),
          ),
        ],
      ),
    ).animate().fade(
      duration: 600.ms,
      delay: 400.ms,
      curve: Curves.easeOut,
    );
  }
}
