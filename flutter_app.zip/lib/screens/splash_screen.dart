import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'chat_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  bool _isLogoVisible = false;
  bool _isTextVisible = false;
  bool _isSubtitleVisible = false;
  bool _isLoadingVisible = false;

  // Анимация вращения для мозга
  late AnimationController _rotationController;

  @override
  void initState() {
    super.initState();

    // Инициализируем контроллер анимации
    _rotationController = AnimationController(
      duration: const Duration(seconds: 10),
      vsync: this,
    )..repeat();

    _startAnimationSequence();
  }

  @override
  void dispose() {
    _rotationController.dispose();
    super.dispose();
  }

  void _startAnimationSequence() {
    // Анимация логотипа
    Future.delayed(const Duration(milliseconds: 500), () {
      if (mounted) {
        setState(() => _isLogoVisible = true);
      }
    });

    // Анимация заголовка
    Future.delayed(const Duration(milliseconds: 1000), () {
      if (mounted) {
        setState(() => _isTextVisible = true);
      }
    });

    // Анимация подзаголовка
    Future.delayed(const Duration(milliseconds: 1500), () {
      if (mounted) {
        setState(() => _isSubtitleVisible = true);
      }
    });

    // Анимация индикатора загрузки
    Future.delayed(const Duration(milliseconds: 2000), () {
      if (mounted) {
        setState(() => _isLoadingVisible = true);
      }
    });

    // Переход на основной экран
    Future.delayed(const Duration(milliseconds: 3500), () {
      if (mounted) {
        Navigator.of(context).pushReplacement(
          PageRouteBuilder(
            pageBuilder: (context, animation, secondaryAnimation) =>
                const ChatScreen(),
            transitionsBuilder: (context, animation, secondaryAnimation, child) {
              const begin = Offset(0.0, 0.0);
              const end = Offset.zero;
              const curve = Curves.easeInOut;

              final tween = Tween(begin: begin, end: end)
                  .chain(CurveTween(curve: curve));

              return FadeTransition(
                opacity: animation,
                child: child,
              );
            },
            transitionDuration: const Duration(milliseconds: 500),
          ),
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isLightMode = theme.brightness == Brightness.light;

    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Логотип с анимированным мозгом ИИ
            AnimatedOpacity(
              opacity: _isLogoVisible ? 1.0 : 0.0,
              duration: const Duration(milliseconds: 500),
              curve: Curves.easeIn,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 500),
                curve: Curves.easeOut,
                transform: Matrix4.identity()
                  ..scale(_isLogoVisible ? 1.0 : 0.8),
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    // Внешний круг
                    Container(
                      width: 140,
                      height: 140,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [
                            theme.colorScheme.primary.withOpacity(0.8),
                            theme.colorScheme.secondary,
                          ],
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: theme.colorScheme.primary.withOpacity(0.3),
                            blurRadius: 20,
                            spreadRadius: 5,
                          ),
                        ],
                      ),
                    ),

                    // Вращающиеся синапсы
                    RotationTransition(
                      turns: _rotationController,
                      child: Container(
                        width: 120,
                        height: 120,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: Colors.white.withOpacity(0.4),
                            width: 1,
                          ),
                        ),
                        child: Stack(
                          children: List.generate(6, (index) {
                            return Positioned(
                              left: 60 + 55 * cos(index * 60 * 3.14 / 180),
                              top: 60 + 55 * sin(index * 60 * 3.14 / 180),
                              child: Container(
                                width: 10,
                                height: 10,
                                decoration: BoxDecoration(
                                  color: theme.colorScheme.tertiary,
                                  shape: BoxShape.circle,
                                ),
                              ),
                            );
                          }),
                        ),
                      ),
                    ),

                    // Внутренний круг (мозг)
                    Container(
                      width: 80,
                      height: 80,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: theme.colorScheme.background,
                        image: const DecorationImage(
                          image: AssetImage('assets/images/ai_logo.png'),
                          fit: BoxFit.cover,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: theme.colorScheme.primary.withOpacity(0.2),
                            blurRadius: 10,
                            spreadRadius: 2,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                    ),

                    // Пульсирующий эффект
                    SpinKitPulse(
                      color: theme.colorScheme.primary.withOpacity(0.3),
                      size: 160.0,
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 32),

            // Заголовок
            AnimatedOpacity(
              opacity: _isTextVisible ? 1.0 : 0.0,
              duration: const Duration(milliseconds: 400),
              child: Text(
                'MULTI AI',
                style: TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 3,
                  color: theme.colorScheme.primary,
                  shadows: [
                    Shadow(
                      color: theme.colorScheme.primary.withOpacity(0.3),
                      blurRadius: 5,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 16),

            // Подзаголовок
            AnimatedOpacity(
              opacity: _isSubtitleVisible ? 1.0 : 0.0,
              duration: const Duration(milliseconds: 400),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 32),
                child: Text(
                  'Доступ к различным моделям искусственного интеллекта в одном приложении',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 16,
                    color: theme.colorScheme.onSurface.withOpacity(0.7),
                  ),
                ),
              ),
            ),

            const SizedBox(height: 48),

            // Индикатор загрузки с анимированными моделями
            AnimatedOpacity(
              opacity: _isLoadingVisible ? 1.0 : 0.0,
              duration: const Duration(milliseconds: 400),
              child: Column(
                children: [
                  // Прогресс с моделями ИИ
                  SizedBox(
                    width: 200,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        // Фоновая линия
                        Container(
                          height: 4,
                          decoration: BoxDecoration(
                            color: theme.colorScheme.surfaceVariant,
                            borderRadius: BorderRadius.circular(2),
                          ),
                        ),

                        // Анимированные точки моделей
                        _buildModelDot(0, 'G', theme.colorScheme.primary),
                        _buildModelDot(0.35, 'C', theme.colorScheme.secondary),
                        _buildModelDot(0.7, 'A', theme.colorScheme.tertiary),

                        // Прогресс бар
                        LinearProgressIndicator(
                          backgroundColor: Colors.transparent,
                          valueColor: AlwaysStoppedAnimation<Color>(
                            theme.colorScheme.primary.withOpacity(0.3),
                          ),
                        ).animate().custom(
                          duration: 2.seconds,
                          begin: 0.0,
                          end: 1.0,
                          builder: (context, value, child) {
                            return SizedBox(
                              width: 200 * value,
                              child: child,
                            );
                          },
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 16),
                  Text(
                    'Инициализация моделей...',
                    style: TextStyle(
                      fontSize: 14,
                      color: theme.colorScheme.onSurface.withOpacity(0.6),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Вспомогательный метод для создания точек моделей на прогресс-баре
  Widget _buildModelDot(double position, String label, Color color) {
    return Positioned(
      left: 200 * position,
      child: Column(
        children: [
          Container(
            width: 20,
            height: 20,
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: color.withOpacity(0.3),
                  blurRadius: 5,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: Center(
              child: Text(
                label,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                ),
              ),
            ),
          ).animate(
            onPlay: (controller) => controller.repeat(),
          ).scaleXY(
            begin: 0.9,
            end: 1.1,
            duration: 1.seconds,
            curve: Curves.easeInOut,
          ).then().scaleXY(
            begin: 1.1,
            end: 0.9,
            duration: 1.seconds,
            curve: Curves.easeInOut,
          ),
        ],
      ),
    );
  }

  // Вспомогательная функция для расчёта положения точек
  double cos(double angle) {
    return Math.cos(angle);
  }

  double sin(double angle) {
    return Math.sin(angle);
  }
}

// Вспомогательный класс для математических функций
class Math {
  static double cos(double angle) {
    return math.cos(angle);
  }

  static double sin(double angle) {
    return math.sin(angle);
  }
}
