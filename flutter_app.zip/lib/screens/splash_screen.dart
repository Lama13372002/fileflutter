import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'chat_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  bool _isLogoVisible = false;
  bool _isTextVisible = false;
  bool _isSubtitleVisible = false;
  bool _isLoadingVisible = false;

  @override
  void initState() {
    super.initState();
    _startAnimationSequence();
  }

  void _startAnimationSequence() {
    // Анимация логотипа
    Future.delayed(const Duration(milliseconds: 500), () {
      if (mounted) {
        setState(() => _isLogoVisible = true);
      }
    });

    // Анимация заголовка
    Future.delayed(const Duration(milliseconds: 1000), () {
      if (mounted) {
        setState(() => _isTextVisible = true);
      }
    });

    // Анимация подзаголовка
    Future.delayed(const Duration(milliseconds: 1500), () {
      if (mounted) {
        setState(() => _isSubtitleVisible = true);
      }
    });

    // Анимация индикатора загрузки
    Future.delayed(const Duration(milliseconds: 2000), () {
      if (mounted) {
        setState(() => _isLoadingVisible = true);
      }
    });

    // Переход на основной экран
    Future.delayed(const Duration(milliseconds: 3500), () {
      if (mounted) {
        Navigator.of(context).pushReplacement(
          PageRouteBuilder(
            pageBuilder: (context, animation, secondaryAnimation) =>
                const ChatScreen(),
            transitionsBuilder: (context, animation, secondaryAnimation, child) {
              const begin = Offset(0.0, 0.0);
              const end = Offset.zero;
              const curve = Curves.easeInOut;

              final tween = Tween(begin: begin, end: end)
                  .chain(CurveTween(curve: curve));

              return FadeTransition(
                opacity: animation,
                child: child,
              );
            },
            transitionDuration: const Duration(milliseconds: 500),
          ),
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isLightMode = theme.brightness == Brightness.light;

    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Логотип
            AnimatedOpacity(
              opacity: _isLogoVisible ? 1.0 : 0.0,
              duration: const Duration(milliseconds: 500),
              curve: Curves.easeIn,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 500),
                curve: Curves.easeOut,
                transform: Matrix4.identity()
                  ..scale(_isLogoVisible ? 1.0 : 0.8),
                child: Icon(
                  Icons.auto_awesome,
                  size: 120,
                  color: theme.colorScheme.primary,
                ),
              ),
            ),

            const SizedBox(height: 32),

            // Заголовок
            AnimatedOpacity(
              opacity: _isTextVisible ? 1.0 : 0.0,
              duration: const Duration(milliseconds: 400),
              child: Text(
                'GEMINI AI',
                style: TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 3,
                  color: theme.colorScheme.primary,
                ),
              ),
            ),

            const SizedBox(height: 16),

            // Подзаголовок
            AnimatedOpacity(
              opacity: _isSubtitleVisible ? 1.0 : 0.0,
              duration: const Duration(milliseconds: 400),
              child: Text(
                'Умный ассистент с расширенными возможностями',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 16,
                  color: theme.colorScheme.onSurface.withOpacity(0.7),
                ),
              ),
            ),

            const SizedBox(height: 48),

            // Индикатор загрузки
            AnimatedOpacity(
              opacity: _isLoadingVisible ? 1.0 : 0.0,
              duration: const Duration(milliseconds: 400),
              child: SpinKitPulse(
                color: theme.colorScheme.primary,
                size: 50.0,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
