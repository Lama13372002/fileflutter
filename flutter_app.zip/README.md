# AI Голосовой Ассистент

Flutter-приложение для общения с ИИ моделью с помощью голоса. Приложение использует:
- **Deepgram** для распознавания речи в реальном времени
- **ElevenLabs** для синтеза естественной речи
- **Gemini** (через CometAPI) для генерации ответов ИИ модели

## Особенности

- Преобразование речи в текст в реальном времени
- Потоковый синтез речи для минимальной задержки
- Визуализация звука во время разговора
- Сохранение истории диалога с ИИ
- Возможность ввода текста вместо голоса

## Требования

- Flutter SDK 3.0.0 или новее
- Необходимые API ключи (Deepgram, ElevenLabs, CometAPI)
- Доступ к интернету для работы сервисов распознавания/синтеза речи

## Установка

1. Клонируйте репозиторий:
```bash
git clone https://github.com/yourusername/flutter_ai_assistant.git
cd flutter_ai_assistant
```

2. Установите зависимости:
```bash
flutter pub get
```

3. Настройте API ключи (см. следующий раздел)

4. Запустите приложение:
```bash
flutter run
```

## Настройка API ключей

Приложение требует API ключи от трех сервисов:

### 1. Deepgram API

1. Зарегистрируйтесь на [Deepgram Console](https://console.deepgram.com/)
2. Создайте новый проект
3. Перейдите в раздел "Keys" и создайте новый API ключ
4. Скопируйте ключ и вставьте его в `lib/utils/app_config.dart`

### 2. ElevenLabs API

1. Зарегистрируйтесь на [ElevenLabs](https://elevenlabs.io/)
2. Перейдите в настройки профиля
3. Найдите или создайте API ключ
4. Скопируйте ключ и вставьте его в `lib/utils/app_config.dart`
5. Для получения ID голоса:
   - Перейдите в "Voice Lab" или "My Voices"
   - Выберите голос, который хотите использовать
   - Нажмите "View" и скопируйте ID голоса
   - Вставьте ID в `lib/utils/app_config.dart`

### 3. CometAPI (для доступа к Gemini)

1. Зарегистрируйтесь на [CometAPI](https://api.cometapi.com/)
2. Создайте новый API ключ
3. Скопируйте ключ и вставьте его в `lib/utils/app_config.dart`

### Обновление файла конфигурации

Откройте файл `lib/utils/app_config.dart` и замените значения по умолчанию вашими API ключами:

```dart
static const String deepgramApiKey = 'YOUR_DEEPGRAM_API_KEY';
static const String elevenLabsApiKey = 'YOUR_ELEVENLABS_API_KEY';
static const String cometApiKey = 'YOUR_COMET_API_KEY';
static const String elevenLabsVoiceId = 'YOUR_VOICE_ID';
```

## Настройка языка

По умолчанию приложение настроено на русский язык. Для изменения языка распознавания речи измените значение `speechRecognitionLanguage` в файле `lib/utils/app_config.dart`:

```dart
// Поддерживаемые языки: en, ru, fr, de, es и другие
// Для многоязычного режима используйте: multi
static const String speechRecognitionLanguage = 'ru';
```

## Расширенные настройки

В файле `lib/utils/app_config.dart` вы можете настроить дополнительные параметры:

- Модель для синтеза речи
- Параметры аудио
- Настройки визуализации
- Цветовую схему и другие элементы интерфейса

## Лицензия

MIT License

## Контакты

Для вопросов и предложений, пожалуйста, создайте issue в репозитории проекта.
