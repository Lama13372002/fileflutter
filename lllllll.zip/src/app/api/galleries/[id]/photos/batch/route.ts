import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

// POST /api/galleries/[id]/photos/batch - пакетное добавление фотографий
export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  // Проверка авторизации
  const session = await getServerSession(authOptions);
  console.log('Пакетная загрузка: Проверка сессии', session ? 'Авторизован' : 'Не авторизован');

  if (!session) {
    return NextResponse.json(
      { error: 'Требуется авторизация' },
      { status: 401 }
    );
  }

  try {
    const galleryId = parseInt(params.id);
    console.log(`Запрос на пакетную загрузку для галереи ID=${galleryId}`);

    // Получаем данные из FormData
    const formData = await request.formData();

    // Проверяем наличие загруженных файлов
    let hasFiles = false;
    for (const [key, value] of formData.entries()) {
      if (value instanceof File) {
        hasFiles = true;
        break;
      }
    }

    if (hasFiles) {
      console.log('Обнаружены файлы для загрузки, перенаправляем на обработку через PhotoGalleryManager');
      // Файлы должны обрабатываться через PhotoGalleryManager, это API больше не используется
      return NextResponse.json({
        message: 'Пожалуйста, используйте прямую загрузку файлов через интерфейс галереи'
      }, { status: 400 });
    }

    // Возвращаем сообщение, что этот метод больше не поддерживается
    return NextResponse.json(
      {
        error: 'Пакетная загрузка по URL больше не поддерживается. Пожалуйста, используйте прямую загрузку файлов.',
        message: 'Функция загрузки изображений по URL удалена. Используйте только загрузку локальных файлов.'
      },
      { status: 400 }
    );
  } catch (error) {
    console.error('Ошибка при обработке запроса на пакетную загрузку:', error);
    return NextResponse.json(
      { error: 'Произошла ошибка при обработке запроса' },
      { status: 500 }
    );
  }
}
