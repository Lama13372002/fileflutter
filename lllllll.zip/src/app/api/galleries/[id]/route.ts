import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { z } from 'zod';

// Схема валидации для редактирования галереи
const updateGallerySchema = z.object({
  id: z.string().or(z.number()).transform(val => Number(val)),
  title: z.string().min(3, 'Название должно содержать минимум 3 символа'),
  description: z.string().optional(),
  slug: z
    .string()
    .regex(/^[a-z0-9-]+$/, 'Slug должен содержать только строчные буквы, цифры и дефисы')
    .min(3, 'Slug должен содержать минимум 3 символа'),
  isPublished: z.boolean().optional(),
});

// GET /api/galleries/[id] - получение данных галереи по ID
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const galleryId = parseInt(params.id);
    console.log(`Получение галереи по ID=${galleryId}`);

    if (isNaN(galleryId)) {
      return NextResponse.json(
        { error: 'ID галереи должен быть числовым' },
        { status: 400 }
      );
    }

    const gallery = await prisma.photoGallery.findUnique({
      where: { id: galleryId },
      include: {
        photos: {
          orderBy: { order: 'asc' },
        },
      },
    });

    if (!gallery) {
      console.log(`Галерея с ID=${galleryId} не найдена`);
      return NextResponse.json(
        { error: 'Галерея не найдена' },
        { status: 404 }
      );
    }

    console.log(`Галерея с ID=${galleryId} успешно найдена`);

    // Добавляем заголовки для предотвращения кеширования
    const headers = new Headers();
    headers.append('Cache-Control', 'no-store, max-age=0');
    headers.append('Pragma', 'no-cache');
    headers.append('Expires', '0');

    return NextResponse.json(gallery, { headers });
  } catch (error) {
    console.error('Ошибка при получении галереи:', error);
    return NextResponse.json(
      { error: 'Ошибка при получении галереи' },
      { status: 500 }
    );
  }
}

// PATCH /api/galleries/[id] - обновление галереи
export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  // Проверка авторизации
  const session = await getServerSession(authOptions);
  console.log('Обновление галереи: Проверка сессии', !!session);

  if (!session) {
    return NextResponse.json(
      { error: 'Требуется авторизация' },
      { status: 401 }
    );
  }

  try {
    const galleryId = parseInt(params.id);
    console.log(`Обновление галереи с ID=${galleryId}: Начало обработки запроса`);

    if (isNaN(galleryId)) {
      return NextResponse.json(
        { error: 'ID галереи должен быть числовым' },
        { status: 400 }
      );
    }

    // Проверяем существование галереи
    const existingGallery = await prisma.photoGallery.findUnique({
      where: { id: galleryId },
    });

    if (!existingGallery) {
      console.log(`Обновление галереи: Галерея с ID=${galleryId} не найдена`);
      return NextResponse.json(
        { error: 'Галерея не найдена' },
        { status: 404 }
      );
    }

    // Получаем данные из FormData
    const formData = await request.formData();
    console.log('Обновление галереи: FormData получен');

    // Извлекаем все поля из FormData
    const title = formData.get('title') as string;
    const description = formData.get('description') as string || '';
    const slug = formData.get('slug') as string;
    const isPublished = formData.get('isPublished') === 'true';

    console.log('Обновление галереи: Данные из формы:', {
      title,
      description: description ? `${description.substring(0, 30)}...` : '',
      slug,
      isPublished
    });

    // Создаем объект данных для валидации
    const galleryData = {
      id: galleryId,
      title,
      description,
      slug,
      isPublished
    };

    // Валидация данных
    console.log('Обновление галереи: Валидация данных');
    const validation = updateGallerySchema.safeParse(galleryData);
    if (!validation.success) {
      console.error('Обновление галереи: Ошибка валидации:', validation.error.format());
      return NextResponse.json(
        { error: 'Ошибка валидации', details: validation.error.format() },
        { status: 400 }
      );
    }

    // Проверяем уникальность slug при изменении
    if (slug !== existingGallery.slug) {
      console.log('Обновление галереи: Проверка уникальности нового slug:', slug);
      const galleryWithSameSlug = await prisma.photoGallery.findFirst({
        where: {
          slug,
          id: { not: galleryId }
        },
      });

      if (galleryWithSameSlug) {
        console.error('Обновление галереи: Галерея с таким slug уже существует:', slug);
        return NextResponse.json(
          { error: 'Галерея с таким slug уже существует' },
          { status: 400 }
        );
      }
    }

    // Обновляем галерею
    console.log('Обновление галереи: Сохранение в базу данных');
    const updatedGallery = await prisma.photoGallery.update({
      where: { id: galleryId },
      data: {
        title: validation.data.title,
        description: validation.data.description,
        slug: validation.data.slug,
        isPublished: validation.data.isPublished,
      },
    });

    console.log('Обновление галереи: Успешно обновлена, ID:', updatedGallery.id);

    // Добавляем заголовки для предотвращения кеширования
    const headers = new Headers();
    headers.append('Cache-Control', 'no-store, max-age=0');
    headers.append('Pragma', 'no-cache');
    headers.append('Expires', '0');

    return NextResponse.json(updatedGallery, { headers });
  } catch (error) {
    console.error('Ошибка при обновлении галереи:', error);

    // Возвращаем детальную информацию об ошибке
    const errorMessage = error instanceof Error
      ? error.message
      : 'Ошибка при обновлении галереи';

    return NextResponse.json(
      { error: errorMessage },
      { status: 500 }
    );
  }
}

// DELETE /api/galleries/[id] - удаление галереи
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  // Проверка авторизации
  const session = await getServerSession(authOptions);
  if (!session) {
    return NextResponse.json(
      { error: 'Требуется авторизация' },
      { status: 401 }
    );
  }

  try {
    const galleryId = parseInt(params.id);
    console.log(`Удаление галереи с ID=${galleryId}: Начало обработки запроса`);

    if (isNaN(galleryId)) {
      return NextResponse.json(
        { error: 'ID галереи должен быть числовым' },
        { status: 400 }
      );
    }

    // Проверяем существование галереи
    const gallery = await prisma.photoGallery.findUnique({
      where: { id: galleryId },
    });

    if (!gallery) {
      console.log(`Удаление галереи: Галерея с ID=${galleryId} не найдена`);
      return NextResponse.json(
        { error: 'Галерея не найдена' },
        { status: 404 }
      );
    }

    // Удаляем галерею (фотографии удалятся каскадно)
    console.log(`Удаление галереи ID=${galleryId}: Выполнение запроса к БД`);
    await prisma.photoGallery.delete({
      where: { id: galleryId },
    });

    console.log(`Удаление галереи ID=${galleryId}: Успешно удалена`);
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Ошибка при удалении галереи:', error);
    return NextResponse.json(
      { error: 'Ошибка при удалении галереи' },
      { status: 500 }
    );
  }
}
