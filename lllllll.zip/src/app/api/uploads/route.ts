import { NextRequest, NextResponse } from 'next/server'
import { writeFile, mkdir } from 'fs/promises'
import { join } from 'path'
import { v4 as uuidv4 } from 'uuid'
import * as fs from 'fs'

// Константы для PostImage API
const POSTIMAGE_API_URL = 'https://postimage.me/api/1/upload'
const PUBLIC_API_KEY = '442c1196f61793728f933be13f35cba416756a1598c5f5e1f97a0316c24db0ae'

// Функция для сохранения файла
async function saveFile(
  file: File,
  folderPath: string
): Promise<string> {
  try {
    // Создаем уникальное имя файла с использованием UUID
    const bytes = await file.arrayBuffer()
    const buffer = Buffer.from(bytes)

    // Получаем расширение файла из его типа или имени
    let fileExtension = file.name.split('.').pop() || 'jpg'
    if (!fileExtension.match(/^[a-z0-9]+$/i)) {
      // Если расширение содержит недопустимые символы, используем безопасное расширение
      fileExtension = 'jpg'
    }

    const fileName = `${uuidv4()}.${fileExtension}`

    // Полный путь к файлу
    const folderPathCleaned = folderPath.replace(/^\/+|\/+$/g, '')

    // Проверяем и создаем директорию uploads в public, если она не существует
    const baseUploadDir = join(process.cwd(), 'public')
    await mkdir(baseUploadDir, { recursive: true })

    // Создаем директорию uploads
    const uploadsDir = join(baseUploadDir, 'uploads')
    await mkdir(uploadsDir, { recursive: true })
    console.log(`Проверка базовой директории uploads: ${uploadsDir}`)

    // Создаем поддиректорию gallery
    const galleryDir = join(uploadsDir, 'gallery')
    await mkdir(galleryDir, { recursive: true })
    console.log(`Проверка директории галереи: ${galleryDir}`)

    // Полный путь к файлу
    const fullPath = join(process.cwd(), 'public', folderPathCleaned, fileName)

    // Выводим информацию о файле перед сохранением
    console.log({
      fileName,
      folderPathCleaned,
      fullPath,
      fileSize: buffer.length
    })

    // Записываем файл
    await writeFile(fullPath, buffer)
    console.log(`Файл успешно сохранен по пути: ${fullPath}`)

    // Проверяем, что файл действительно существует после сохранения
    if (fs.existsSync(fullPath)) {
      console.log(`Проверка после сохранения: файл существует по пути ${fullPath}`)
    } else {
      console.error(`Проверка после сохранения: файл не найден по пути ${fullPath}`)
      // Пытаемся получить информацию о директории
      try {
        const dirStats = fs.statSync(join(process.cwd(), 'public', folderPathCleaned))
        console.log(`Информация о директории:`, dirStats)

        // Перечисляем файлы в директории
        const files = fs.readdirSync(join(process.cwd(), 'public', folderPathCleaned))
        console.log(`Файлы в директории:`, files)
      } catch (dirErr) {
        console.error(`Ошибка при проверке директории:`, dirErr)
      }
    }

    // Возвращаем публичный URL для доступа к файлу
    return `/${folderPathCleaned}/${fileName}`
  } catch (error) {
    console.error('Ошибка при сохранении файла:', error)
    throw error
  }
}

// Функция для загрузки файла на PostImage API
async function uploadToPostImage(
  file: File,
  title?: string,
  description?: string,
  tags?: string
): Promise<string> {
  try {
    console.log('Начинаем загрузку на PostImage:', {
      fileName: file.name,
      fileSize: file.size,
      fileType: file.type,
      title,
      tags
    })

    // Создаем FormData для отправки на PostImage
    const formData = new FormData()
    formData.append('source', file)
    formData.append('key', PUBLIC_API_KEY)
    formData.append('format', 'json')

    if (title) {
      formData.append('title', title)
    }

    if (description) {
      formData.append('description', description)
    }

    if (tags) {
      formData.append('tags', tags)
    }

    // Отправляем запрос на PostImage API
    const response = await fetch(POSTIMAGE_API_URL, {
      method: 'POST',
      headers: {
        'X-API-Key': PUBLIC_API_KEY,
      },
      body: formData
    })

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }

    // Парсим ответ
    const data = await response.json()
    console.log('Ответ от PostImage API:', data)

    if (data.status_code !== 200 || !data.image) {
      throw new Error(data.error?.message || 'Неизвестная ошибка при загрузке изображения')
    }

    // Возвращаем URL загруженного изображения
    return data.image.url
  } catch (error) {
    console.error('Ошибка при загрузке изображения на PostImage:', error)
    throw error
  }
}

export async function POST(req: NextRequest) {
  console.log('Начало обработки запроса на загрузку файла');

  try {
    const formData = await req.formData();
    const file = formData.get('file') as File | null;
    const folder = formData.get('folder') as string | null;
    const usePostImage = formData.get('usePostImage') === 'true';

    // Получаем дополнительные параметры для PostImage
    const title = formData.get('title') as string | null;
    const description = formData.get('description') as string | null;
    const tags = formData.get('tags') as string | null;

    console.log('Получен запрос на загрузку:', {
      fileName: file?.name,
      fileSize: file?.size,
      fileType: file?.type,
      folder,
      usePostImage,
      title,
      tags
    });

    if (!file) {
      console.error('Ошибка: файл не найден в запросе');
      return NextResponse.json({ error: 'Файл не найден' }, { status: 400 });
    }

    // Проверка размера файла
    if (file.size > 20 * 1024 * 1024) { // 20MB
      console.error('Ошибка: превышен максимальный размер файла', file.size);
      return NextResponse.json({ error: 'Превышен максимальный размер файла (20 МБ)' }, { status: 400 });
    }

    // Проверка типа файла
    const validImageTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    if (!validImageTypes.includes(file.type)) {
      console.warn('Предупреждение: загружен файл неизвестного типа', file.type);
    }

    // Устанавливаем целевую директорию
    let targetFolder = folder || 'uploads/gallery';
    console.log('Использование папки для загрузки:', targetFolder);

    // Проверка на допустимые папки для загрузки
    const allowedFolders = ['uploads/reviews', 'uploads/blog', 'uploads/gallery'];

    if (!allowedFolders.includes(targetFolder)) {
      console.error('Недопустимая папка для загрузки:', targetFolder);
      return NextResponse.json(
        { error: `Недопустимая папка для загрузки: ${targetFolder}. Разрешенные папки: ${allowedFolders.join(', ')}` },
        { status: 400 }
      );
    }

    // Для галереи всегда используем только локальное хранилище
    if (targetFolder === 'uploads/gallery') {
      // Отключаем использование PostImage для галереи
      console.log('Для галереи используется только локальное хранилище');

      // Сохраняем файл и получаем URL
      const fileUrl = await saveFile(file, targetFolder);
      console.log('Файл для галереи успешно сохранен локально, URL:', fileUrl);

      return NextResponse.json({ url: fileUrl });
    }

    // Если указано использовать PostImage для других разделов
    if (usePostImage) {
      try {
        console.log('Начало загрузки на PostImage');
        const imageUrl = await uploadToPostImage(file, title || undefined, description || undefined, tags || undefined);
        console.log('Файл успешно загружен на PostImage:', imageUrl);
        return NextResponse.json({ url: imageUrl });
      } catch (error) {
        console.error('Ошибка при загрузке на PostImage, переключаемся на локальное хранилище:', error);
        // Если произошла ошибка при загрузке на PostImage, сохраняем файл локально
        // продолжаем выполнение и загружаем файл локально
      }
    }

    // Сохраняем файл и получаем URL
    console.log('Сохраняем файл в локальное хранилище');
    const fileUrl = await saveFile(file, targetFolder);
    console.log('Файл успешно сохранен локально, URL:', fileUrl);

    return NextResponse.json({ url: fileUrl });
  } catch (error) {
    console.error('Ошибка при загрузке файла:', error);
    return NextResponse.json(
      {
        error: `Не удалось загрузить файл: ${(error as Error).message}`,
        stack: error instanceof Error ? error.stack : undefined
      },
      { status: 500 }
    );
  }
}
