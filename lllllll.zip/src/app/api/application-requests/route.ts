import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import emailService from '@/lib/email-service' // Импортируем сервис электронной почты

// GET /api/application-requests - получение списка заявок
export async function GET() {
  try {
    const requests = await prisma.applicationRequest.findMany({
      orderBy: {
        createdAt: 'desc',
      },
    })

    return NextResponse.json({ requests })
  } catch (error) {
    console.error('Error fetching application requests:', error)
    return NextResponse.json(
      { error: 'Не удалось загрузить заявки' },
      { status: 500 }
    )
  }
}

// Допустимые значения для способа связи
const VALID_CONTACT_METHODS = ['telegram', 'whatsapp', 'call'];

// POST /api/application-requests - создание новой заявки
export async function POST(request: Request) {
  console.log('POST request to /api/application-requests received');
  let savedApplicationRequest; // Объявляем переменную для доступа в блоке email

  try {
    const data = await request.json();
    console.log('Request data:', data);

    // Базовая валидация
    if (!data.name || !data.phone || !data.contactMethod) {
      console.error('Validation error - missing required fields');
      return NextResponse.json(
        { error: 'Не все обязательные поля заполнены' },
        { status: 400 }
      );
    }

    // Проверка допустимых значений contactMethod
    if (!VALID_CONTACT_METHODS.includes(data.contactMethod)) {
      console.error('Validation error - invalid contact method:', data.contactMethod);
      return NextResponse.json(
        { error: 'Неверный способ связи. Допустимые значения: telegram, whatsapp, call' },
        { status: 400 }
      );
    }

    // Создание заявки
    savedApplicationRequest = await prisma.applicationRequest.create({
      data: {
        name: data.name,
        phone: data.phone,
        contactMethod: data.contactMethod,
        status: 'new'
      },
    });

    console.log('ApplicationRequest created successfully:', savedApplicationRequest);

    // Определяем способ связи в читаемом формате
    const contactMethodText = (() => {
      switch(data.contactMethod) {
        case 'telegram': return 'Telegram';
        case 'whatsapp': return 'WhatsApp';
        case 'call': return 'Звонок';
        default: return data.contactMethod;
      }
    })();

    // Отправляем Email уведомление ПОСЛЕ успешного сохранения в БД
    if (emailService.isConfigured() && process.env.APPLICATION_FORM_EMAIL) {
      try {
        const emailSent = await emailService.sendEmail({
          to: process.env.APPLICATION_FORM_EMAIL,
          subject: `Новая заявка с формы 'Оставить заявку' от ${data.name}`,
          text: `Получена новая заявка с сайта:\n
Имя: ${data.name}
Телефон: ${data.phone}
Предпочтительный способ связи: ${contactMethodText}

ID заявки: ${savedApplicationRequest.id}`,
          html: `
            <h2>Новая заявка с формы 'Оставить заявку'</h2>
            <p><strong>ID заявки:</strong> ${savedApplicationRequest.id}</p>
            <p><strong>Имя:</strong> ${data.name}</p>
            <p><strong>Телефон:</strong> <a href="tel:${data.phone.replace(/[\s()-]/g, '')}">${data.phone}</a></p>
            <p><strong>Предпочтительный способ связи:</strong> ${contactMethodText}</p>
            <hr>
            <p><small>Это автоматическое уведомление. Заявка сохранена в базе данных.</small></p>
          `,
        });

        if (emailSent) {
          console.log(`Email уведомление для заявки ${savedApplicationRequest.id} успешно отправлено`);
        } else {
          console.error(`Ошибка при отправке email для заявки ${savedApplicationRequest.id}`);
        }
      } catch (mailError) {
        // Логируем ошибку отправки email, но НЕ прерываем успешный ответ клиенту
        console.error(`Ошибка при отправке email для заявки ${savedApplicationRequest.id}:`, mailError);
      }
    } else {
      console.warn(`Email-сервис не настроен или отсутствует APPLICATION_FORM_EMAIL для заявки ${savedApplicationRequest.id}`);
    }

    return NextResponse.json({
      success: true,
      request: savedApplicationRequest
    });

  } catch (error: any) {
    console.error('Error creating application request:', error);

    // Детальное логирование для диагностики
    if (error.code) {
      console.error('Prisma error code:', error.code);
    }

    if (error.meta) {
      console.error('Prisma error metadata:', error.meta);
    }

    const errorMessage = error instanceof Error ? error.message : 'Неизвестная ошибка сервера';
    const requestId = savedApplicationRequest?.id ? ` (Заявка ID: ${savedApplicationRequest.id})` : '';

    return NextResponse.json(
      { error: `Не удалось создать заявку: ${errorMessage}${requestId}` },
      { status: 500 }
    );
  }
}

// PATCH /api/application-requests/:id - обновление статуса заявки
export async function PATCH(request: Request) {
  try {
    const data = await request.json()
    const { id, status } = data

    if (!id || !status) {
      return NextResponse.json(
        { error: 'ID и статус обязательны' },
        { status: 400 }
      )
    }

    const updatedRequest = await prisma.applicationRequest.update({
      where: { id: Number(id) },
      data: { status },
    })

    return NextResponse.json({ success: true, request: updatedRequest })
  } catch (error) {
    console.error('Error updating application request:', error)
    return NextResponse.json(
      { error: 'Не удалось обновить заявку' },
      { status: 500 }
    )
  }
}

// DELETE /api/application-requests - удаление заявки
export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json(
        { error: 'ID заявки не указан' },
        { status: 400 }
      )
    }

    await prisma.applicationRequest.delete({
      where: { id: Number(id) },
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting application request:', error)
    return NextResponse.json(
      { error: 'Не удалось удалить заявку' },
      { status: 500 }
    )
  }
}
