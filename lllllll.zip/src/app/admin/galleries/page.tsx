import { Metadata } from "next";
import { unstable_noStore } from "next/cache";
import Link from "next/link";
import Image from "next/image";
import prisma from "@/lib/prisma";
import { formatDistanceToNow } from "date-fns";
import { ru } from "date-fns/locale";
import AdminHeader from "@/components/admin/AdminHeader";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import {
  PlusCircle,
  Edit,
  Image as ImageIcon,
  Eye,
  Calendar,
  Trash2
} from "lucide-react";
import AdminGalleryActions from "@/components/admin/gallery/AdminGalleryActions";

// Отключаем кеширование для обеспечения актуальности данных
export const dynamic = 'force-dynamic';
export const revalidate = 0;

export const metadata: Metadata = {
  title: "Фотогалереи | Админ панель",
  description: "Управление фотогалереями сайта",
};

async function getGalleries() {
  // Отключаем кеширование для этого запроса
  unstable_noStore();

  try {
    console.log('Получение списка галерей: Начинаем запрос к БД');
    const galleries = await prisma.photoGallery.findMany({
      include: {
        photos: {
          take: 1,
          orderBy: { order: "asc" },
        },
        _count: {
          select: { photos: true },
        },
      },
      orderBy: { createdAt: "desc" },
    });
    console.log(`Получение списка галерей: Найдено ${galleries.length} галерей`);
    return galleries;
  } catch (error) {
    console.error("Ошибка при получении галерей:", error);
    return [];
  }
}

export default async function AdminGalleriesPage() {
  const galleries = await getGalleries();

  return (
    <div className="container mx-auto p-6">
      <AdminHeader
        title="Управление фотогалереями"
        description="Создавайте и редактируйте фотогалереи сайта"
      />

      <div className="flex justify-between mb-6">
        <h2 className="text-xl font-medium">Список фотогалерей</h2>
        <Button asChild>
          <Link href="/admin/galleries/create" className="flex items-center">
            <PlusCircle className="mr-2 h-4 w-4" />
            Создать галерею
          </Link>
        </Button>
      </div>

      {galleries.length === 0 ? (
        <div className="text-center p-8 bg-gray-50 rounded-lg">
          <p className="text-lg text-gray-600 mb-4">
            У вас пока нет ни одной фотогалереи
          </p>
          <Button asChild>
            <Link href="/admin/galleries/create" className="flex items-center justify-center">
              <PlusCircle className="mr-2 h-4 w-4" />
              Создать первую галерею
            </Link>
          </Button>
        </div>
      ) : (
        <div className="grid gap-6">
          {galleries.map((gallery) => (
            <Card key={gallery.id} className="overflow-hidden shadow-sm">
              <div className="flex flex-col md:flex-row">
                <div className="md:w-1/4 h-64 md:h-auto relative">
                  {gallery.photos[0] ? (
                    <Image
                      src={gallery.photos[0].url}
                      alt={gallery.title}
                      fill
                      sizes="(max-width: 768px) 100vw, 25vw"
                      className="object-cover"
                    />
                  ) : (
                    <div className="w-full h-full bg-gray-200 flex items-center justify-center">
                      <span className="text-gray-400">Нет фото</span>
                    </div>
                  )}
                </div>

                <CardContent className="flex-1 p-6 flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-start mb-2">
                      <CardTitle className="text-xl font-bold">{gallery.title}</CardTitle>
                      <div className="flex items-center gap-2">
                        {gallery.isPublished ? (
                          <span className="px-2 py-1 bg-green-100 text-green-800 rounded-md text-xs">
                            Опубликовано
                          </span>
                        ) : (
                          <span className="px-2 py-1 bg-gray-100 text-gray-800 rounded-md text-xs">
                            Черновик
                          </span>
                        )}
                      </div>
                    </div>

                    <CardDescription>
                      <p className="text-gray-500 mb-1">
                        URL: <span className="font-mono text-sm">/gallery/{gallery.slug}</span>
                      </p>
                      <p className="text-gray-500 mb-4">
                        Фотографий: {gallery._count.photos}
                      </p>

                      {gallery.description && (
                        <p className="text-gray-700 mb-4 line-clamp-2">{gallery.description}</p>
                      )}
                    </CardDescription>
                  </div>

                  <div className="mt-4 flex flex-wrap items-center gap-2">
                    <Button asChild variant="outline" size="sm">
                      <Link href={`/admin/galleries/${gallery.id}`} className="flex items-center gap-1">
                        <ImageIcon className="h-4 w-4" />
                        Управление фотографиями
                      </Link>
                    </Button>
                    <Button asChild variant="outline" size="sm">
                      <Link href={`/admin/galleries/edit/${gallery.id}`} className="flex items-center gap-1">
                        <Edit className="h-4 w-4" />
                        Редактировать
                      </Link>
                    </Button>
                    <AdminGalleryActions galleryId={gallery.id} />
                    <Button asChild variant="ghost" size="sm">
                      <Link href={`/gallery/${gallery.slug}`} target="_blank" className="flex items-center gap-1">
                        <Eye className="h-4 w-4" />
                        Просмотр
                      </Link>
                    </Button>
                  </div>

                  <p className="text-xs text-gray-400 mt-4 flex items-center gap-1">
                    <Calendar className="h-3.5 w-3.5" />
                    Создано: {formatDistanceToNow(new Date(gallery.createdAt), { addSuffix: true, locale: ru })}
                  </p>
                </CardContent>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
