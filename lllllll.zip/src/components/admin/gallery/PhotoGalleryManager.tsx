"use client";

import { useState } from "react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import {
  PlusCircle,
  Pencil,
  Trash2,
  MoveUp,
  MoveDown,
  Loader2,
  X,
  Upload
} from "lucide-react";

// Тип данных для галереи и фотографий
interface GalleryPhoto {
  id: number;
  url: string;
  title: string | null;
  description: string | null;
  order: number;
}

interface Gallery {
  id: number;
  title: string;
  slug: string;
  photos: GalleryPhoto[];
}

// Схема валидации для добавления/редактирования фотографии
const photoFormSchema = z.object({
  title: z.string().optional(),
  description: z.string().optional(),
});

type PhotoFormValues = z.infer<typeof photoFormSchema>;

// Новая схема для множественной загрузки фотографий
const batchPhotoFormSchema = z.object({
  title: z.string().optional(),
});

type BatchPhotoFormValues = z.infer<typeof batchPhotoFormSchema>;

interface PhotoGalleryManagerProps {
  gallery: Gallery;
}

export default function PhotoGalleryManager({ gallery }: PhotoGalleryManagerProps) {
  const [photos, setPhotos] = useState<GalleryPhoto[]>(gallery.photos);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isBatchDialogOpen, setIsBatchDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedPhoto, setSelectedPhoto] = useState<GalleryPhoto | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [fileToUpload, setFileToUpload] = useState<File | null>(null);
  const [filesToUpload, setFilesToUpload] = useState<FileList | null>(null);
  const router = useRouter();

  // Форма для добавления фотографии
  const addForm = useForm<PhotoFormValues>({
    resolver: zodResolver(photoFormSchema),
    defaultValues: {
      title: "",
      description: "",
    },
  });

  // Форма для редактирования фотографии
  const editForm = useForm<PhotoFormValues>({
    resolver: zodResolver(photoFormSchema),
    defaultValues: {
      title: "",
      description: "",
    },
  });

  // Форма для пакетного добавления фотографий
  const batchForm = useForm<BatchPhotoFormValues>({
    resolver: zodResolver(batchPhotoFormSchema),
    defaultValues: {
      title: "",
    },
  });

  // Обработчик выбора файла
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFileToUpload(e.target.files[0]);
    }
  };

  // Обработчик выбора нескольких файлов
  const handleMultipleFilesChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setFilesToUpload(e.target.files);
    }
  };

  // Добавление фотографии
  const onAddPhoto = async (values: PhotoFormValues) => {
    setIsLoading(true);

    try {
      if (!fileToUpload) {
        throw new Error("Необходимо выбрать файл для загрузки");
      }

      console.log("Загрузка файла перед добавлением в галерею:", fileToUpload.name);

      const formData = new FormData();
      formData.append('file', fileToUpload);
      formData.append('folder', 'uploads/gallery');

      console.log("Отправка запроса на загрузку файла...");
      const uploadResponse = await fetch('/api/uploads', {
        method: 'POST',
        body: formData
      });

      if (!uploadResponse.ok) {
        const error = await uploadResponse.json().catch(() => ({}));
        console.error("Ошибка загрузки файла:", error);
        throw new Error(error.error || `Ошибка загрузки файла (${uploadResponse.status})`);
      }

      console.log("Получен ответ от сервера загрузки");
      const uploadResult = await uploadResponse.json().catch(() => {
        throw new Error(`Не удалось прочитать ответ сервера при загрузке файла`);
      });

      const photoUrl = uploadResult.url;
      console.log("Файл успешно загружен, полученный URL:", photoUrl);

      // Используем FormData вместо JSON
      const photoFormData = new FormData();
      photoFormData.append("url", photoUrl);
      if (values.title) photoFormData.append("title", values.title);
      if (values.description) photoFormData.append("description", values.description);

      console.log("Отправка запроса на добавление фото в галерею ID:", gallery.id);
      console.log("Данные для добавления:", {
        url: photoUrl,
        title: values.title || 'не указано',
        description: values.description ? (values.description.length > 20 ? values.description.substring(0, 20) + '...' : values.description) : 'не указано'
      });

      const response = await fetch(`/api/galleries/${gallery.id}/photos`, {
        method: "POST",
        body: photoFormData,
      });

      if (!response.ok) {
        const error = await response.json().catch(() => ({}));
        console.error("Ошибка ответа сервера:", response.status, error);
        throw new Error(error.error || `Ошибка сервера (${response.status})`);
      }

      const newPhoto = await response.json().catch(() => {
        throw new Error(`Не удалось прочитать ответ сервера`);
      });

      console.log("Фотография успешно добавлена:", newPhoto);

      // Обновляем список фотографий
      setPhotos(prevPhotos => [...prevPhotos, newPhoto]);
      toast.success("Фотография успешно добавлена");
      addForm.reset();
      setFileToUpload(null);
      setIsAddDialogOpen(false);
      router.refresh();
    } catch (error) {
      console.error("Error adding photo:", error);
      toast.error(
        error instanceof Error
          ? error.message
          : "Произошла ошибка при добавлении фотографии"
      );
    } finally {
      setIsLoading(false);
    }
  };

  // Пакетное добавление фотографий
  const onAddBatchPhotos = async (values: BatchPhotoFormValues) => {
    setIsLoading(true);

    try {
      if (!filesToUpload || filesToUpload.length === 0) {
        throw new Error("Необходимо выбрать файлы для загрузки");
      }

      let successCount = 0;
      let errorCount = 0;

      // Создаем массив для хранения всех созданных фотографий
      const createdPhotos: GalleryPhoto[] = [];
      const errors: string[] = [];

      // Перебираем все файлы и загружаем их последовательно
      for (let i = 0; i < filesToUpload.length; i++) {
        const file = filesToUpload[i];
        try {
          console.log(`Загрузка файла ${i+1}/${filesToUpload.length}: ${file.name}`);

          // Загружаем файл
          const uploadFormData = new FormData();
          uploadFormData.append('file', file);
          uploadFormData.append('folder', 'uploads/gallery');

          const uploadResponse = await fetch('/api/uploads', {
            method: 'POST',
            body: uploadFormData
          });

          if (!uploadResponse.ok) {
            const error = await uploadResponse.json().catch(() => ({}));
            throw new Error(error.error || `Ошибка загрузки файла (${uploadResponse.status})`);
          }

          const uploadResult = await uploadResponse.json();
          const photoUrl = uploadResult.url;
          console.log(`Файл ${file.name} успешно загружен, URL: ${photoUrl}`);

          // Создаем запись в базе данных для фотографии
          const photoFormData = new FormData();
          photoFormData.append("url", photoUrl);
          if (values.title) {
            // Добавляем номер к названию при пакетной загрузке
            photoFormData.append("title", `${values.title} ${i + 1}`);
          }

          console.log(`Добавление в галерею ID=${gallery.id} фото: ${photoUrl}`);
          const response = await fetch(`/api/galleries/${gallery.id}/photos`, {
            method: "POST",
            body: photoFormData,
          });

          if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.error || `Ошибка сервера при добавлении фото (${response.status})`);
          }

          const newPhoto = await response.json();
          console.log(`Фото ${file.name} успешно добавлено в галерею`);
          createdPhotos.push(newPhoto);
          successCount++;
        } catch (err) {
          console.error(`Ошибка при загрузке файла ${file.name}:`, err);
          errors.push(`${file.name}: ${err instanceof Error ? err.message : 'Неизвестная ошибка'}`);
          errorCount++;
        }
      }

      // Обновляем список фотографий, добавляя все успешно созданные
      if (createdPhotos.length > 0) {
        setPhotos(prevPhotos => [...prevPhotos, ...createdPhotos]);
      }

      // Отображаем результат
      if (errorCount > 0) {
        if (successCount > 0) {
          toast.warning(`Добавлено ${successCount} из ${filesToUpload.length} фотографий. ${errorCount} фото не удалось загрузить.`, {
            description: errors.join('\n').substring(0, 200) + (errors.join('\n').length > 200 ? '...' : '')
          });
        } else {
          toast.error(`Не удалось загрузить ни одной фотографии из ${filesToUpload.length}`, {
            description: errors.join('\n').substring(0, 200) + (errors.join('\n').length > 200 ? '...' : '')
          });
        }
      } else {
        toast.success(`Успешно добавлено ${successCount} фотографий`);
      }

      batchForm.reset();
      setFilesToUpload(null);
      setIsBatchDialogOpen(false);
      router.refresh();
    } catch (error) {
      console.error("Error adding photos:", error);
      toast.error(
        error instanceof Error
          ? error.message
          : "Произошла ошибка при добавлении фотографий"
      );
    } finally {
      setIsLoading(false);
    }
  };

  // Редактирование фотографии
  const onEditPhoto = async (values: PhotoFormValues) => {
    if (!selectedPhoto) return;

    setIsLoading(true);

    try {
      // Используем FormData вместо JSON
      // Больше не позволяем менять URL фотографии
      const formData = new FormData();
      if (values.title) formData.append("title", values.title);
      if (values.description) formData.append("description", values.description);

      const response = await fetch(`/api/galleries/photos/${selectedPhoto.id}`, {
        method: "PATCH",
        body: formData,
      });

      if (!response.ok) {
        const error = await response.json().catch(() => ({}));
        throw new Error(error.error || `Ошибка сервера (${response.status})`);
      }

      const updatedPhoto = await response.json().catch(() => {
        throw new Error(`Не удалось прочитать ответ сервера`);
      });

      setPhotos(photos.map(photo =>
        photo.id === selectedPhoto.id ? updatedPhoto : photo
      ));

      toast.success("Фотография успешно обновлена");
      setIsEditDialogOpen(false);
      router.refresh();
    } catch (error) {
      console.error("Error updating photo:", error);
      toast.error(
        error instanceof Error
          ? error.message
          : "Произошла ошибка при обновлении фотографии"
      );
    } finally {
      setIsLoading(false);
    }
  };

  // Удаление фотографии
  const onDeletePhoto = async () => {
    if (!selectedPhoto) return;

    setIsLoading(true);

    try {
      const response = await fetch(`/api/galleries/photos/${selectedPhoto.id}`, {
        method: "DELETE",
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || "Произошла ошибка при удалении фотографии");
      }

      setPhotos(photos.filter(photo => photo.id !== selectedPhoto.id));
      toast.success("Фотография успешно удалена");
      setIsDeleteDialogOpen(false);
      router.refresh();
    } catch (error) {
      console.error("Error deleting photo:", error);
      toast.error(
        error instanceof Error
          ? error.message
          : "Произошла ошибка при удалении фотографии"
      );
    } finally {
      setIsLoading(false);
    }
  };

  // Изменение порядка фотографии
  const changePhotoOrder = async (photoId: number, direction: "up" | "down") => {
    const photoIndex = photos.findIndex(p => p.id === photoId);
    if (photoIndex === -1) return;

    // Если перемещаем вверх первую или вниз последнюю фотографию - ничего не делаем
    if ((direction === "up" && photoIndex === 0) ||
        (direction === "down" && photoIndex === photos.length - 1)) {
      return;
    }

    const newIndex = direction === "up" ? photoIndex - 1 : photoIndex + 1;

    // Сохраняем текущий порядок
    const currentOrder = photos[photoIndex].order;
    const targetOrder = photos[newIndex].order;

    setIsLoading(true);

    try {
      // Обновляем порядок для текущей фотографии
      const formData1 = new FormData();
      formData1.append("order", targetOrder.toString());

      const response1 = await fetch(`/api/galleries/photos/${photoId}`, {
        method: "PATCH",
        body: formData1
      });

      if (!response1.ok) {
        throw new Error("Ошибка при изменении порядка фотографии");
      }

      // Обновляем порядок для другой фотографии
      const formData2 = new FormData();
      formData2.append("order", currentOrder.toString());

      const response2 = await fetch(`/api/galleries/photos/${photos[newIndex].id}`, {
        method: "PATCH",
        body: formData2
      });

      if (!response2.ok) {
        throw new Error("Ошибка при изменении порядка фотографии");
      }

      // Обновляем локальный массив
      const newPhotos = [...photos];

      // Меняем местами фотографии
      [newPhotos[photoIndex], newPhotos[newIndex]] = [newPhotos[newIndex], newPhotos[photoIndex]];

      // Обновляем порядок
      newPhotos[photoIndex].order = currentOrder;
      newPhotos[newIndex].order = targetOrder;

      setPhotos(newPhotos);
      toast.success("Порядок фотографий изменен");
      router.refresh();
    } catch (error) {
      console.error("Error changing photo order:", error);
      toast.error(
        error instanceof Error
          ? error.message
          : "Ошибка при изменении порядка фотографий"
      );
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div>
      <div className="flex flex-wrap gap-4 mb-6">
        <Dialog open={isAddDialogOpen} onOpenChange={(open) => {
          setIsAddDialogOpen(open);
          if (!open) {
            setFileToUpload(null);
            addForm.reset();
          }
        }}>
          <DialogTrigger asChild>
            <Button>
              <PlusCircle className="mr-2 h-4 w-4" />
              Добавить фотографию
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Добавить новую фотографию</DialogTitle>
            </DialogHeader>
            <Form {...addForm}>
              <form onSubmit={addForm.handleSubmit(onAddPhoto)} className="space-y-6">
                <div className="border rounded-md p-4">
                  <h3 className="font-medium mb-2">Загрузить файл</h3>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileChange}
                    className="w-full"
                    required
                  />
                  {fileToUpload && (
                    <div className="mt-2">
                      <p className="text-sm text-green-600">Выбран файл: {fileToUpload.name}</p>
                    </div>
                  )}
                </div>
                <FormField
                  control={addForm.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Название (необязательно)</FormLabel>
                      <FormControl>
                        <Input placeholder="Название фотографии" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={addForm.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Описание (необязательно)</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Описание фотографии"
                          className="min-h-24"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="flex justify-end gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setIsAddDialogOpen(false);
                      setFileToUpload(null);
                      addForm.reset();
                    }}
                    disabled={isLoading}
                  >
                    Отмена
                  </Button>
                  <Button type="submit" disabled={isLoading}>
                    {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Добавить
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>

        <Dialog open={isBatchDialogOpen} onOpenChange={(open) => {
          setIsBatchDialogOpen(open);
          if (!open) {
            setFilesToUpload(null);
            batchForm.reset();
          }
        }}>
          <DialogTrigger asChild>
            <Button variant="outline">
              <Upload className="mr-2 h-4 w-4" />
              Пакетная загрузка
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Пакетная загрузка фотографий</DialogTitle>
            </DialogHeader>
            <Form {...batchForm}>
              <form onSubmit={batchForm.handleSubmit(onAddBatchPhotos)} className="space-y-6">
                <div className="border rounded-md p-4">
                  <h3 className="font-medium mb-2">Выберите файлы для загрузки</h3>
                  <input
                    type="file"
                    accept="image/*"
                    multiple
                    onChange={handleMultipleFilesChange}
                    className="w-full"
                    required
                  />
                  {filesToUpload && filesToUpload.length > 0 && (
                    <div className="mt-2">
                      <p className="text-sm text-green-600">
                        Выбрано файлов: {filesToUpload.length}
                      </p>
                    </div>
                  )}
                </div>

                <FormField
                  control={batchForm.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Общее название (необязательно)</FormLabel>
                      <FormControl>
                        <Input placeholder="Название для фотографий" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex justify-end gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setIsBatchDialogOpen(false);
                      setFilesToUpload(null);
                      batchForm.reset();
                    }}
                    disabled={isLoading}
                  >
                    Отмена
                  </Button>
                  <Button type="submit" disabled={isLoading}>
                    {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Загрузить все
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {photos.length === 0 ? (
        <div className="text-center p-8 bg-gray-50 rounded-lg">
          <p className="text-lg text-gray-600 mb-4">
            В этой галерее пока нет фотографий
          </p>
          <Button onClick={() => setIsAddDialogOpen(true)}>
            <PlusCircle className="mr-2 h-4 w-4" />
            Добавить первую фотографию
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {photos.map((photo, index) => (
            <Card key={photo.id} className="overflow-hidden">
              <CardHeader className="p-0">
                <div className="relative aspect-video">
                  <Image
                    src={photo.url}
                    alt={photo.title || `Фото ${index + 1}`}
                    fill
                    sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                    className="object-cover"
                  />
                </div>
              </CardHeader>
              <CardContent className="p-4">
                <CardTitle className="text-lg mb-2">
                  {photo.title || `Фото ${index + 1}`}
                </CardTitle>
                {photo.description && (
                  <p className="text-sm text-gray-500 line-clamp-2">{photo.description}</p>
                )}
              </CardContent>
              <CardFooter className="flex justify-between p-4 pt-0">
                <div className="flex gap-1">
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={index === 0 || isLoading}
                    onClick={() => changePhotoOrder(photo.id, "up")}
                  >
                    <MoveUp className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={index === photos.length - 1 || isLoading}
                    onClick={() => changePhotoOrder(photo.id, "down")}
                  >
                    <MoveDown className="h-4 w-4" />
                  </Button>
                </div>
                <div className="flex gap-1">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setSelectedPhoto(photo);
                      editForm.reset({
                        title: photo.title || "",
                        description: photo.description || "",
                      });
                      setIsEditDialogOpen(true);
                    }}
                  >
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => {
                      setSelectedPhoto(photo);
                      setIsDeleteDialogOpen(true);
                    }}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}

      {/* Диалог редактирования фотографии */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Редактировать фотографию</DialogTitle>
          </DialogHeader>
          <Form {...editForm}>
            <form onSubmit={editForm.handleSubmit(onEditPhoto)} className="space-y-6">
              <FormField
                control={editForm.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Название (необязательно)</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={editForm.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Описание (необязательно)</FormLabel>
                    <FormControl>
                      <Textarea className="min-h-24" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex justify-end gap-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsEditDialogOpen(false)}
                  disabled={isLoading}
                >
                  Отмена
                </Button>
                <Button type="submit" disabled={isLoading}>
                  {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Сохранить
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Диалог подтверждения удаления */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Вы уверены?</AlertDialogTitle>
            <AlertDialogDescription>
              Это действие нельзя отменить. Фотография будет безвозвратно удалена из галереи.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isLoading}>Отмена</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                onDeletePhoto();
              }}
              disabled={isLoading}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {isLoading ? "Удаление..." : "Удалить"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
